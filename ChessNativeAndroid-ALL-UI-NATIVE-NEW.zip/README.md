# Cờ Vua Native Android — no WebView

Dự án này chuyển giao diện cờ vua sang Android native (Kotlin/Canvas/View), không nhúng HTML
và không chạy WebView.

## Build chỉ bằng điện thoại
1. Tạo repository GitHub.
2. Upload toàn bộ nội dung ZIP này lên repository.
3. Mở tab Actions.
4. Chạy workflow `Build APK`.
5. Mở job hoàn tất → Artifacts → `ChessNative-debug-apk`.
6. Tải APK về điện thoại và cài đặt.

## Nội dung native
Giao diện chơi, bàn cờ, thanh đánh giá, thanh người chơi, nhật ký nước đi, quân bắt được,
thanh nút dưới, popover tùy chọn, màn hình kết quả và khung xem lại/phân tích được tổ chức
thành native Android components.

Stockfish được tải trong GitHub Actions và đặt thành executable native asset lúc build.
Không có WebView trong Android project.
