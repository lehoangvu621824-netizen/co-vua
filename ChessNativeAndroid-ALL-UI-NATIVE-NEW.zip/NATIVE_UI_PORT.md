# Native UI coverage

The Android project intentionally contains no WebView and no HTML renderer.

Native screens/components represented from the supplied HTML:
- Main game stage
- Opponent/player bars with Elo and clocks
- Evaluation bar
- Chess board and coordinates
- Move journal
- Captured-piece area
- Bottom navigation: Options / Captured / Analysis / Undo / Redo
- Options popover: New game / Resign
- Captured popover
- Result modal: Checkmate / analysis / replay
- Review-summary layout: graph/players + accuracy/statistics
- Review-move layout: board + commentator + move list
- Commentator message area
- Analysis classification labels: Book, Brilliant, Best, Great, Good, Inaccuracy, Mistake, Blunder, Miss

Important:
The supplied HTML contains JavaScript-specific behavior (DOM rendering, browser workers,
CSS media queries and browser event handling). Native Android cannot literally reuse those
DOM/CSS elements. They are represented as Android Canvas/View components instead.
