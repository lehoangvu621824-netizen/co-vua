package com.chess.nativeapp
import android.content.Context
import java.io.*

class StockfishEngine(private val context:Context){
    private var p:Process?=null;private var w:BufferedWriter?=null;private var r:BufferedReader?=null
    private var t:Thread?=null;private var listener:((String)->Unit)?=null
    fun setListener(x:(String)->Unit){listener=x}
    fun start(){try{
        val f=File(context.filesDir,"stockfish");if(!f.exists())context.assets.open("stockfish").use{a->f.outputStream().use{a.copyTo(it)}}
        f.setExecutable(true,false);p=ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
        w=p!!.outputStream.bufferedWriter();r=p!!.inputStream.bufferedReader()
        send("uci");t=Thread{try{var line:String?;while(r!!.readLine().also{line=it}!=null){val s=line!!;if(s.startsWith("bestmove ")){listener?.invoke(s.substring(9).trim().split(" ")[0])}}}catch(_:Exception){}}.also{it.isDaemon=true;it.start()}
    }catch(_:Exception){}}
    private fun send(s:String){w?.write(s+"\n");w?.flush()}
    fun position(m:String){send("ucinewgame");send("position startpos${if(m.isBlank())"" else " moves $m}") }
    fun go(ms:Int){send("go movetime $ms")}
    fun stop(){try{send("quit")}catch(_:Exception){};try{p?.destroy()}catch(_:Exception){};p=null}
}
