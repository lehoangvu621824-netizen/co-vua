package com.chess.nativeapp

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class ChessView(context: Context) : View(context) {
    private val bg=Color.rgb(22,22,20); private val panel=Color.rgb(31,30,28)
    private val light=Color.rgb(238,244,249); private val dark=Color.rgb(61,119,190)
    private val hi=Color.rgb(205,194,116); private val fg=Color.rgb(235,235,232)
    private val b=Array(8){CharArray(8){' '}}
    private val history=mutableListOf<State>(); private val moves=mutableListOf<String>()
    private val redo=mutableListOf<State>()
    private var sr=-1; private var sc=-1; private var white=true; private var thinking=false
    private var engine:StockfishEngine=StockfishEngine(context)
    private val capturedW=StringBuilder(); private val capturedB=StringBuilder()

    init { reset(); setBackgroundColor(bg); engine.setListener { uci -> post { applyBotMove(uci) } }; engine.start() }

    fun stopEngine(){engine.stop()}
    private fun reset(){
        val back="rnbqkbnr"
        for(i in 0..7){b[0][i]=back[i];b[1][i]='p';b[6][i]='P';b[7][i]=back[i].uppercaseChar()}
    }
    private data class State(val board:Array<CharArray>,val white:Boolean,val moves:List<String>,val cw:String,val cb:String)
    private fun snap()=State(b.map{it.clone()}.toTypedArray(),white,moves.toList(),capturedW.toString(),capturedB.toString())
    private fun restore(s:State){for(r in 0..7)for(c in 0..7)b[r][c]=s.board[r][c];white=s.white;moves.clear();moves.addAll(s.moves);capturedW.clear();capturedW.append(s.cw);capturedB.clear();capturedB.append(s.cb);sr=-1;sc=-1;thinking=false;invalidate()}

    override fun onDraw(c:Canvas){
        super.onDraw(c); c.drawColor(bg); val w=width.toFloat();val h=height.toFloat()
        val hh=70f;val fh=78f;val side=min(520f,w*.38f)
        val size=min(h-hh-fh,w-side-48f).coerceAtLeast(300f);val bx=24f;val by=hh+(h-hh-fh-size)/2;val q=size/8
        fill(c,Color.rgb(20,20,19));c.drawRect(0f,0f,w,hh,p);txt(c,"♟  Cờ Vua",28f,45f,27f,fg,true)
        fill(c,panel);c.drawRoundRect(bx,by-54,bx+size,by-5,10f,10f,p)
        txt(c,if(white)"Đen" else "Bạn",bx+16,by-23,18f,fg,true);txt(c,if(thinking)"Đang suy nghĩ…" else "10:00",bx+size-120,by-23,15f,fg,true)
        for(r in 0..7)for(cc in 0..7){
            val x=bx+cc*q;val y=by+r*q;fill(c,if((r+cc)%2==0)light else dark);c.drawRect(x,y,x+q,y+q,p)
            if(r==sr&&cc==sc){fill(c,hi);c.drawRect(x,y,x+q,y+q,p)}
            val pc=b[r][cc];if(pc!=' ')txt(c,glyph(pc),x+q/2,y+q*.72f,q*.72f,if(pc.isUpperCase())Color.WHITE else Color.DKGRAY,true,Paint.Align.CENTER)
            if(cc==0)txt(c,"${8-r}",x+6,y+17,11f,if((r+cc)%2==0)dark else light,true)
            if(r==7)txt(c,"abcdefgh"[cc].toString(),x+q-6,y+q-7,11f,if((r+cc)%2==0)dark else light,true,Paint.Align.RIGHT)
        }
        val rx=bx+size+28;val rw=w-rx-24;fill(c,panel);c.drawRoundRect(rx,hh+8,rx+rw,h-fh-8,12f,12f,p)
        txt(c,"♟  NHẬT KÝ NƯỚC ĐI",rx+18,hh+43,18f,fg,true)
        var yy=hh+86
        moves.forEachIndexed{i,mv->fill(c,if(i==moves.lastIndex)Color.rgb(59,76,39) else Color.rgb(40,40,37));c.drawRoundRect(rx+16,yy-23,rx+rw-16,yy+19,8f,8f,p);txt(c,"${i+1}.",rx+25,yy+4,13f,Color.LTGRAY);txt(c,mv,rx+60,yy+4,15f,fg,true);yy+=48}
        txt(c,"Bắt: $capturedW",rx+18,h-fh-38,12f,Color.LTGRAY);txt(c,"Đen: $capturedB",rx+18,h-fh-18,12f,Color.LTGRAY)
        fill(c,Color.rgb(25,25,23));c.drawRect(0,h-fh,w,h,p)
        button(c,w*.68,h-fh+12,w*.80,h-12,"‹  Quay lại",history.isNotEmpty()&&!thinking)
        button(c,w*.81,h-fh+12,w*.94,h-12,"›  Tiếp",redo.isNotEmpty()&&!thinking)
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action!=MotionEvent.ACTION_UP||thinking)return true
        val w=width.toFloat();val h=height.toFloat();val hh=70f;val fh=78f;val side=min(520f,w*.38f)
        val size=min(h-hh-fh,w-side-48f).coerceAtLeast(300f);val bx=24f;val by=hh+(h-hh-fh-size)/2;val q=size/8
        if(e.x>w*.68&&e.x<w*.80&&e.y>h-fh){if(history.isNotEmpty())restore(history.removeLast());return true}
        if(e.x>w*.81&&e.x<w*.94&&e.y>h-fh){if(redo.isNotEmpty())restore(redo.removeLast());return true}
        if(e.x !in bx..bx+size||e.y !in by..by+size)return true
        val cc=((e.x-bx)/q).toInt();val r=((e.y-by)/q).toInt()
        if(sr<0){if(b[r][cc]!=' '&&b[r][cc].isUpperCase()==white){sr=r;sc=cc;invalidate()}}
        else {if(r==sr&&cc==sc){sr=-1;sc=-1;invalidate();return true};makeMove(sr,sc,r,cc)}
        return true
    }
    private fun makeMove(a:Int,c:Int,r:Int,d:Int){
        val pc=b[a][c];if(pc==' '||pc.isUpperCase()!=white)return
        history.add(snap());redo.clear()
        val cap=b[r][d];if(cap!=' '){if(cap.isUpperCase())capturedW.append(glyph(cap));else capturedB.append(glyph(cap))}
        b[r][d]=pc;b[a][c]=' ';moves.add("${sq(c,a)}-${sq(d,r)}");white=false;sr=-1;sc=-1;thinking=true;invalidate()
        engine.position(movesToUci());engine.go(1200)
    }
    private fun applyBotMove(u:String){
        if(u.length<4){thinking=false;white=true;invalidate();return}
        val a=u[0]-'a';val ar=8-(u[1]-'0');val d=u[2]-'a';val dr=8-(u[3]-'0')
        if(ar in 0..7&&dr in 0..7&&a in 0..7&&d in 0..7){
            val cap=b[dr][d];if(cap!=' ')if(cap.isUpperCase())capturedW.append(glyph(cap))else capturedB.append(glyph(cap))
            val pc=b[ar][a];b[dr][d]=pc;b[ar][a]=' ';moves.add("${sq(a,ar)}-${sq(d,dr)}")
        }
        white=true;thinking=false;invalidate()
    }
    private fun movesToUci()=moves.joinToString(" "){it.substring(0,2)+it.substring(3,5)}
    private fun sq(c:Int,r:Int)="abcdefgh"[c].toString()+(8-r)
    private fun glyph(x:Char)=when(x.lowercaseChar()){'p'->"♟";'r'->"♜";'n'->"♞";'b'->"♝";'q'->"♛";'k'->"♚";else->""}
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private fun fill(c:Canvas,col:Int){p.style=Paint.Style.FILL;p.color=col}
    private fun txt(c:Canvas,s:String,x:Float,y:Float,z:Float,col:Int,bold:Boolean=false,align:Paint.Align=Paint.Align.LEFT){p.style=Paint.Style.FILL;p.color=col;p.textSize=z;p.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;p.textAlign=align;c.drawText(s,x,y,p)}
    private fun button(c:Canvas,l:Float,t:Float,r:Float,b:Float,s:String,on:Boolean){fill(c,if(on)Color.rgb(43,43,40) else Color.rgb(27,27,25));c.drawRoundRect(l,t,r,b,10f,10f,p);txt(c,s,(l+r)/2,t+35,15f,if(on)fg else Color.DKGRAY,true,Paint.Align.CENTER)}
}
