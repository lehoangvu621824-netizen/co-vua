# Cờ Vua TV

Project Android WebView cho Android TV.

- Bàn cờ tự thu nhỏ để vừa màn hình TV.
- Hình nền ứng dụng tối kiểu cờ vua.
- Build bằng GitHub Actions.
- Có APK universal và cấu hình armeabi-v7a.

Mở Actions → Build Co Vua APK → Run workflow → tải artifact `co-vua-apk-32bit`.
