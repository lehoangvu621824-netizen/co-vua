# Chess Android APK build package

This ZIP contains the original Android project plus:
- `gradle/wrapper/gradle-wrapper.properties` configured for Gradle 9.3.1
- `.github/workflows/build-apk.yml` to build `app-debug.apk` with GitHub Actions

On GitHub: upload the project, open **Actions**, select **Build APK**, then run the workflow.
The generated `app-debug.apk` is uploaded as the `app-debug` artifact.
