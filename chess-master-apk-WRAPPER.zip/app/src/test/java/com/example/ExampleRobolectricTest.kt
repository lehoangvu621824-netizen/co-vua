package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.chess.engine.ChessAI
import com.example.chess.engine.ChessBoard
import com.example.chess.engine.ChessRules
import com.example.chess.model.AIDifficulty
import com.example.chess.model.PieceColor
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Cờ Vua", appName)
  }

  @Test
  fun `test initial chess board legal moves`() {
    val board = ChessBoard()
    val whiteMoves = ChessRules.getLegalMoves(board, PieceColor.WHITE)
    // In standard chess initial position, White has 16 pawn moves (8 single + 8 double) + 4 knight moves = 20 legal moves
    assertEquals(20, whiteMoves.size)
  }

  @Test
  fun `test AI finds a valid move`() {
    val board = ChessBoard()
    val aiMove = ChessAI.findBestMove(board, AIDifficulty.MEDIUM)
    assertNotNull(aiMove)
  }
}
