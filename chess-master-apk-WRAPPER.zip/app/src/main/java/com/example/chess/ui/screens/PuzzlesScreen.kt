package com.example.chess.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.chess.data.PuzzleRepository
import com.example.chess.model.PieceColor
import com.example.chess.ui.components.ChessBoardView
import com.example.chess.viewmodel.ChessViewModel
import com.example.chess.viewmodel.PuzzleStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PuzzlesScreen(
    viewModel: ChessViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val puzzles = PuzzleRepository.puzzles
    val currentPuzzle = puzzles.getOrNull(uiState.currentPuzzleIndex)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Câu Đố Cờ Vua (Tactics)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Bài tập ${uiState.currentPuzzleIndex + 1}/${puzzles.size}: ${currentPuzzle?.title ?: ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.togglePuzzleHint() }) {
                        Icon(
                            imageVector = if (uiState.showPuzzleHint) Icons.Default.Lightbulb else Icons.Outlined.Lightbulb,
                            contentDescription = "Gợi ý",
                            tint = if (uiState.showPuzzleHint) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Puzzle index selector strip
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(puzzles) { index, pz ->
                    FilterChip(
                        selected = index == uiState.currentPuzzleIndex,
                        onClick = { viewModel.loadPuzzle(index) },
                        label = { Text("Bài ${index + 1}") },
                        leadingIcon = {
                            if (index == uiState.currentPuzzleIndex && uiState.puzzleStatus == PuzzleStatus.SOLVED) {
                                Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp))
                            }
                        }
                    )
                }
            }

            // Puzzle Prompt & Category Banner
            if (currentPuzzle != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${currentPuzzle.category} • Độ khó: ${currentPuzzle.difficulty}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = if (currentPuzzle.playerColor == PieceColor.WHITE) "Lượt Trắng đi - Tìm nước cờ tối ưu!" else "Lượt Đen đi - Tìm nước cờ tối ưu!",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        AssistChip(
                            onClick = { viewModel.togglePuzzleHint() },
                            label = { Text("Gợi ý") },
                            leadingIcon = { Icon(Icons.Default.Lightbulb, null, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
            }

            // Chess Board
            ChessBoardView(
                board = uiState.board,
                isFlipped = uiState.isFlipped,
                boardTheme = uiState.boardTheme,
                selectedSquare = uiState.selectedSquare,
                legalMoves = uiState.legalMoves,
                lastMove = uiState.lastMove,
                kingInCheckSquare = uiState.kingInCheckSquare,
                hintMove = null,
                onSquareClicked = { viewModel.onSquareClicked(it) }
            )

            // Solution Status Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp)),
                color = when (uiState.puzzleStatus) {
                    PuzzleStatus.SOLVED -> MaterialTheme.colorScheme.primaryContainer
                    PuzzleStatus.WRONG_MOVE -> MaterialTheme.colorScheme.errorContainer
                    PuzzleStatus.CORRECT_STEP -> MaterialTheme.colorScheme.tertiaryContainer
                    PuzzleStatus.SOLVING -> MaterialTheme.colorScheme.surfaceVariant
                }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = when (uiState.puzzleStatus) {
                                PuzzleStatus.SOLVED -> Icons.Default.CheckCircle
                                PuzzleStatus.WRONG_MOVE -> Icons.Default.Cancel
                                PuzzleStatus.CORRECT_STEP -> Icons.Default.ThumbUp
                                PuzzleStatus.SOLVING -> Icons.Default.Psychology
                            },
                            contentDescription = null,
                            tint = when (uiState.puzzleStatus) {
                                PuzzleStatus.SOLVED -> MaterialTheme.colorScheme.primary
                                PuzzleStatus.WRONG_MOVE -> MaterialTheme.colorScheme.error
                                PuzzleStatus.CORRECT_STEP -> MaterialTheme.colorScheme.tertiary
                                PuzzleStatus.SOLVING -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = when (uiState.puzzleStatus) {
                                PuzzleStatus.SOLVED -> "Chính xác! Bạn đã giải xong câu đố!"
                                PuzzleStatus.WRONG_MOVE -> "Nước đi chưa tối ưu! Hãy thử lại."
                                PuzzleStatus.CORRECT_STEP -> "Nước đi đúng! Tiếp tục..."
                                PuzzleStatus.SOLVING -> "Hãy di chuyển quân cờ trên bàn."
                            },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (uiState.puzzleStatus == PuzzleStatus.WRONG_MOVE) {
                        FilledTonalButton(
                            onClick = { viewModel.retryPuzzle() },
                            modifier = Modifier.testTag("retry_puzzle_button")
                        ) {
                            Text("Thử Lại")
                        }
                    } else if (uiState.puzzleStatus == PuzzleStatus.SOLVED) {
                        Button(
                            onClick = { viewModel.nextPuzzle() },
                            modifier = Modifier.testTag("next_puzzle_button")
                        ) {
                            Text("Tiếp Tục")
                        }
                    }
                }
            }

            // Hint / Explanation Card
            if (uiState.showPuzzleHint && currentPuzzle != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    tonalElevation = 2.dp
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gợi Ý & Lời Giải", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentPuzzle.hint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (uiState.puzzleStatus == PuzzleStatus.SOLVED) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Phân tích: ${currentPuzzle.explanation}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
