package com.example.chess.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.TimeControl
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

enum class ClockTurn {
    NONE,
    TOP,
    BOTTOM
}

@Composable
fun ChessClockScreen(
    modifier: Modifier = Modifier
) {
    var selectedPreset by remember { mutableStateOf(TimeControl.BLITZ_3_2) }
    var topTimeMs by remember { mutableStateOf(selectedPreset.initialSeconds * 1000L) }
    var bottomTimeMs by remember { mutableStateOf(selectedPreset.initialSeconds * 1000L) }
    var activeTurn by remember { mutableStateOf(ClockTurn.NONE) }
    var isRunning by remember { mutableStateOf(false) }
    var topMoves by remember { mutableStateOf(0) }
    var bottomMoves by remember { mutableStateOf(0) }
    var showPresetDialog by remember { mutableStateOf(false) }

    fun resetClocks(preset: TimeControl = selectedPreset) {
        isRunning = false
        activeTurn = ClockTurn.NONE
        topTimeMs = preset.initialSeconds * 1000L
        bottomTimeMs = preset.initialSeconds * 1000L
        topMoves = 0
        bottomMoves = 0
    }

    // Countdown Coroutine
    LaunchedEffect(isRunning, activeTurn) {
        if (isRunning && activeTurn != ClockTurn.NONE) {
            val intervalMs = 50L
            while (isActive) {
                delay(intervalMs)
                if (activeTurn == ClockTurn.TOP) {
                    if (topTimeMs <= 0) {
                        topTimeMs = 0
                        isRunning = false
                        break
                    } else {
                        topTimeMs -= intervalMs
                    }
                } else if (activeTurn == ClockTurn.BOTTOM) {
                    if (bottomTimeMs <= 0) {
                        bottomTimeMs = 0
                        isRunning = false
                        break
                    } else {
                        bottomTimeMs -= intervalMs
                    }
                }
            }
        }
    }

    fun onTopTap() {
        if (topTimeMs <= 0 || bottomTimeMs <= 0) return
        if (activeTurn == ClockTurn.TOP || activeTurn == ClockTurn.NONE) {
            // Apply increment to Top
            if (activeTurn == ClockTurn.TOP) {
                topTimeMs += selectedPreset.incrementSeconds * 1000L
                topMoves++
            }
            activeTurn = ClockTurn.BOTTOM
            isRunning = true
        }
    }

    fun onBottomTap() {
        if (topTimeMs <= 0 || bottomTimeMs <= 0) return
        if (activeTurn == ClockTurn.BOTTOM || activeTurn == ClockTurn.NONE) {
            // Apply increment to Bottom
            if (activeTurn == ClockTurn.BOTTOM) {
                bottomTimeMs += selectedPreset.incrementSeconds * 1000L
                bottomMoves++
            }
            activeTurn = ClockTurn.TOP
            isRunning = true
        }
    }

    fun formatTime(ms: Long): String {
        val totalSecs = (ms + 999) / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return if (totalSecs < 10) {
            val tenths = (ms % 1000) / 100
            String.format("%d.%d", totalSecs, tenths)
        } else {
            String.format("%02d:%02d", mins, secs)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Player Clock (Flipped 180° for opponent)
            val isTopActive = activeTurn == ClockTurn.TOP && isRunning
            val isTopUrgent = topTimeMs in 1..15000L
            val isTopTimeout = topTimeMs <= 0

            val topBgColor by animateColorAsState(
                targetValue = when {
                    isTopTimeout -> MaterialTheme.colorScheme.error
                    isTopUrgent -> MaterialTheme.colorScheme.errorContainer
                    isTopActive -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                label = "topClockBg"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(topBgColor)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { onTopTap() }
                    )
                    .testTag("clock_top_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.rotate(180f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isTopTimeout) "HẾT GIỜ (FLAG)" else formatTime(topTimeMs),
                        fontSize = if (isTopTimeout) 28.sp else 54.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            isTopTimeout -> MaterialTheme.colorScheme.onError
                            isTopUrgent -> MaterialTheme.colorScheme.onErrorContainer
                            isTopActive -> MaterialTheme.colorScheme.onPrimaryContainer
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Số nước đi: $topMoves",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }

            // Middle Control Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .padding(horizontal = 12.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Time Preset Button
                    FilledTonalButton(
                        onClick = { showPresetDialog = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Schedule, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(selectedPreset.label)
                    }

                    // Play/Pause Button
                    IconButton(
                        onClick = { isRunning = !isRunning },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isRunning) "Tạm dừng" else "Bắt đầu",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    // Reset Button
                    IconButton(
                        onClick = { resetClocks() }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Đặt lại giờ")
                    }
                }
            }

            // Bottom Player Clock (Normal Orientation)
            val isBottomActive = activeTurn == ClockTurn.BOTTOM && isRunning
            val isBottomUrgent = bottomTimeMs in 1..15000L
            val isBottomTimeout = bottomTimeMs <= 0

            val bottomBgColor by animateColorAsState(
                targetValue = when {
                    isBottomTimeout -> MaterialTheme.colorScheme.error
                    isBottomUrgent -> MaterialTheme.colorScheme.errorContainer
                    isBottomActive -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                label = "bottomClockBg"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(bottomBgColor)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { onBottomTap() }
                    )
                    .testTag("clock_bottom_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isBottomTimeout) "HẾT GIỜ (FLAG)" else formatTime(bottomTimeMs),
                        fontSize = if (isBottomTimeout) 28.sp else 54.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            isBottomTimeout -> MaterialTheme.colorScheme.onError
                            isBottomUrgent -> MaterialTheme.colorScheme.onErrorContainer
                            isBottomActive -> MaterialTheme.colorScheme.onPrimaryContainer
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Số nước đi: $bottomMoves",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Preset Dialog
        if (showPresetDialog) {
            val presets = listOf(
                TimeControl.BULLET_1_0,
                TimeControl.BLITZ_3_2,
                TimeControl.BLITZ_5_3,
                TimeControl.RAPID_10_0,
                TimeControl.CLASSICAL_15_10
            )

            AlertDialog(
                onDismissRequest = { showPresetDialog = false },
                title = { Text("Chọn Chế Độ Giờ Thi Đấu") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.forEach { preset ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp)),
                                color = if (selectedPreset == preset) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                onClick = {
                                    selectedPreset = preset
                                    resetClocks(preset)
                                    showPresetDialog = false
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(preset.label, fontWeight = FontWeight.Bold)
                                    if (selectedPreset == preset) {
                                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPresetDialog = false }) {
                        Text("Đóng")
                    }
                }
            )
        }
    }
}
