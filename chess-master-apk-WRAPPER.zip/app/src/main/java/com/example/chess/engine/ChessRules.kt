package com.example.chess.engine

import com.example.chess.model.*

object ChessRules {

    fun isSquareAttacked(board: ChessBoard, square: Square, byColor: PieceColor): Boolean {
        val targetCol = square.col
        val targetRow = square.row

        // 1. Attacked by Pawns
        val pawnRow = if (byColor == PieceColor.WHITE) targetRow - 1 else targetRow + 1
        if (pawnRow in 0..7) {
            if (targetCol - 1 in 0..7) {
                val piece = board.getPiece(targetCol - 1, pawnRow)
                if (piece != null && piece.color == byColor && piece.type == PieceType.PAWN) return true
            }
            if (targetCol + 1 in 0..7) {
                val piece = board.getPiece(targetCol + 1, pawnRow)
                if (piece != null && piece.color == byColor && piece.type == PieceType.PAWN) return true
            }
        }

        // 2. Attacked by Knights
        val knightOffsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((dc, dr) in knightOffsets) {
            val c = targetCol + dc
            val r = targetRow + dr
            if (c in 0..7 && r in 0..7) {
                val p = board.getPiece(c, r)
                if (p != null && p.color == byColor && p.type == PieceType.KNIGHT) return true
            }
        }

        // 3. Attacked by King
        val kingOffsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((dc, dr) in kingOffsets) {
            val c = targetCol + dc
            val r = targetRow + dr
            if (c in 0..7 && r in 0..7) {
                val p = board.getPiece(c, r)
                if (p != null && p.color == byColor && p.type == PieceType.KING) return true
            }
        }

        // 4. Attacked along Straight Lines (Rook or Queen)
        val straightDirs = arrayOf(Pair(0, 1), Pair(0, -1), Pair(1, 0), Pair(-1, 0))
        for ((dc, dr) in straightDirs) {
            var c = targetCol + dc
            var r = targetRow + dr
            while (c in 0..7 && r in 0..7) {
                val p = board.getPiece(c, r)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break // blocked by any piece
                }
                c += dc
                r += dr
            }
        }

        // 5. Attacked along Diagonals (Bishop or Queen)
        val diagDirs = arrayOf(Pair(1, 1), Pair(1, -1), Pair(-1, 1), Pair(-1, -1))
        for ((dc, dr) in diagDirs) {
            var c = targetCol + dc
            var r = targetRow + dr
            while (c in 0..7 && r in 0..7) {
                val p = board.getPiece(c, r)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break // blocked
                }
                c += dc
                r += dr
            }
        }

        return false
    }

    fun isKingInCheck(board: ChessBoard, color: PieceColor): Boolean {
        val kingSq = board.findKing(color) ?: return false
        return isSquareAttacked(board, kingSq, color.opposite())
    }

    fun generatePseudoLegalMoves(board: ChessBoard, color: PieceColor): List<Move> {
        val moves = mutableListOf<Move>()
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = board.getPiece(c, r) ?: continue
                if (piece.color != color) continue
                val from = Square(c, r)

                when (piece.type) {
                    PieceType.PAWN -> generatePawnMoves(board, from, piece, moves)
                    PieceType.KNIGHT -> generateKnightMoves(board, from, piece, moves)
                    PieceType.BISHOP -> generateSlidingMoves(board, from, piece, moves, diagDirs)
                    PieceType.ROOK -> generateSlidingMoves(board, from, piece, moves, straightDirs)
                    PieceType.QUEEN -> {
                        generateSlidingMoves(board, from, piece, moves, straightDirs)
                        generateSlidingMoves(board, from, piece, moves, diagDirs)
                    }
                    PieceType.KING -> generateKingMoves(board, from, piece, moves)
                }
            }
        }
        return moves
    }

    private val straightDirs = arrayOf(Pair(0, 1), Pair(0, -1), Pair(1, 0), Pair(-1, 0))
    private val diagDirs = arrayOf(Pair(1, 1), Pair(1, -1), Pair(-1, 1), Pair(-1, -1))

    private fun generatePawnMoves(
        board: ChessBoard,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>
    ) {
        val forward = if (piece.color == PieceColor.WHITE) 1 else -1
        val startRow = if (piece.color == PieceColor.WHITE) 1 else 6
        val promoRow = if (piece.color == PieceColor.WHITE) 7 else 0

        // Single step forward
        val oneStepRow = from.row + forward
        if (oneStepRow in 0..7 && board.getPiece(from.col, oneStepRow) == null) {
            val to = Square(from.col, oneStepRow)
            if (oneStepRow == promoRow) {
                for (promo in arrayOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)) {
                    moves.add(Move(from, to, piece, null, promotion = promo))
                }
            } else {
                moves.add(Move(from, to, piece))
                // Double step forward
                if (from.row == startRow) {
                    val twoStepRow = from.row + 2 * forward
                    if (board.getPiece(from.col, twoStepRow) == null) {
                        moves.add(Move(from, Square(from.col, twoStepRow), piece))
                    }
                }
            }
        }

        // Diagonal captures
        for (dc in arrayOf(-1, 1)) {
            val toCol = from.col + dc
            val toRow = from.row + forward
            if (toCol in 0..7 && toRow in 0..7) {
                val targetPiece = board.getPiece(toCol, toRow)
                val to = Square(toCol, toRow)
                if (targetPiece != null && targetPiece.color != piece.color) {
                    if (toRow == promoRow) {
                        for (promo in arrayOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)) {
                            moves.add(Move(from, to, piece, targetPiece, promotion = promo))
                        }
                    } else {
                        moves.add(Move(from, to, piece, targetPiece))
                    }
                } else if (board.enPassantTarget != null && board.enPassantTarget == to) {
                    // En Passant capture
                    val capturedPawn = board.getPiece(toCol, from.row)
                    if (capturedPawn != null && capturedPawn.color != piece.color && capturedPawn.type == PieceType.PAWN) {
                        moves.add(Move(from, to, piece, capturedPawn, isEnPassant = true))
                    }
                }
            }
        }
    }

    private fun generateKnightMoves(
        board: ChessBoard,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>
    ) {
        val offsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((dc, dr) in offsets) {
            val c = from.col + dc
            val r = from.row + dr
            if (c in 0..7 && r in 0..7) {
                val target = board.getPiece(c, r)
                if (target == null) {
                    moves.add(Move(from, Square(c, r), piece))
                } else if (target.color != piece.color) {
                    moves.add(Move(from, Square(c, r), piece, target))
                }
            }
        }
    }

    private fun generateSlidingMoves(
        board: ChessBoard,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>,
        directions: Array<Pair<Int, Int>>
    ) {
        for ((dc, dr) in directions) {
            var c = from.col + dc
            var r = from.row + dr
            while (c in 0..7 && r in 0..7) {
                val target = board.getPiece(c, r)
                if (target == null) {
                    moves.add(Move(from, Square(c, r), piece))
                } else {
                    if (target.color != piece.color) {
                        moves.add(Move(from, Square(c, r), piece, target))
                    }
                    break
                }
                c += dc
                r += dr
            }
        }
    }

    private fun generateKingMoves(
        board: ChessBoard,
        from: Square,
        piece: Piece,
        moves: MutableList<Move>
    ) {
        val offsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((dc, dr) in offsets) {
            val c = from.col + dc
            val r = from.row + dr
            if (c in 0..7 && r in 0..7) {
                val target = board.getPiece(c, r)
                if (target == null) {
                    moves.add(Move(from, Square(c, r), piece))
                } else if (target.color != piece.color) {
                    moves.add(Move(from, Square(c, r), piece, target))
                }
            }
        }

        // Castling
        val isWhite = piece.color == PieceColor.WHITE
        val kingRow = if (isWhite) 0 else 7
        if (from.col == 4 && from.row == kingRow) {
            val rights = board.castlingRights
            val kingSide = if (isWhite) rights.whiteKingSide else rights.blackKingSide
            val queenSide = if (isWhite) rights.whiteQueenSide else rights.blackQueenSide

            // Kingside (O-O): columns 5 and 6 must be empty, king not in check, squares 4,5,6 not attacked
            if (kingSide && board.getPiece(5, kingRow) == null && board.getPiece(6, kingRow) == null) {
                val rook = board.getPiece(7, kingRow)
                if (rook != null && rook.color == piece.color && rook.type == PieceType.ROOK) {
                    if (!isSquareAttacked(board, Square(4, kingRow), piece.color.opposite()) &&
                        !isSquareAttacked(board, Square(5, kingRow), piece.color.opposite()) &&
                        !isSquareAttacked(board, Square(6, kingRow), piece.color.opposite())
                    ) {
                        moves.add(Move(from, Square(6, kingRow), piece, isCastling = true, isKingsideCastle = true))
                    }
                }
            }

            // Queenside (O-O-O): columns 1, 2, 3 must be empty, king not in check, squares 4,3,2 not attacked
            if (queenSide && board.getPiece(1, kingRow) == null && board.getPiece(2, kingRow) == null && board.getPiece(3, kingRow) == null) {
                val rook = board.getPiece(0, kingRow)
                if (rook != null && rook.color == piece.color && rook.type == PieceType.ROOK) {
                    if (!isSquareAttacked(board, Square(4, kingRow), piece.color.opposite()) &&
                        !isSquareAttacked(board, Square(3, kingRow), piece.color.opposite()) &&
                        !isSquareAttacked(board, Square(2, kingRow), piece.color.opposite())
                    ) {
                        moves.add(Move(from, Square(2, kingRow), piece, isCastling = true, isQueensideCastle = true))
                    }
                }
            }
        }
    }

    fun applyMove(board: ChessBoard, move: Move): ChessBoard {
        val newBoard = board.copy()
        val p = move.piece

        // Remove piece from source
        newBoard.setPiece(move.from, null)

        // En passant capture removal
        if (move.isEnPassant) {
            newBoard.setPiece(move.to.col, move.from.row, null)
        }

        // Place moved or promoted piece on target
        val placedPiece = if (move.promotion != null) Piece(move.promotion, p.color) else p
        newBoard.setPiece(move.to, placedPiece)

        // Castling rook move
        if (move.isCastling) {
            val r = move.from.row
            if (move.isKingsideCastle) {
                val rook = newBoard.getPiece(7, r)
                newBoard.setPiece(7, r, null)
                newBoard.setPiece(5, r, rook)
            } else if (move.isQueensideCastle) {
                val rook = newBoard.getPiece(0, r)
                newBoard.setPiece(0, r, null)
                newBoard.setPiece(3, r, rook)
            }
        }

        // Update Castling rights
        var wK = newBoard.castlingRights.whiteKingSide
        var wQ = newBoard.castlingRights.whiteQueenSide
        var bK = newBoard.castlingRights.blackKingSide
        var bQ = newBoard.castlingRights.blackQueenSide

        if (p.type == PieceType.KING) {
            if (p.color == PieceColor.WHITE) {
                wK = false
                wQ = false
            } else {
                bK = false
                bQ = false
            }
        }
        if (move.from.col == 0 && move.from.row == 0) wQ = false
        if (move.from.col == 7 && move.from.row == 0) wK = false
        if (move.from.col == 0 && move.from.row == 7) bQ = false
        if (move.from.col == 7 && move.from.row == 7) bK = false

        if (move.to.col == 0 && move.to.row == 0) wQ = false
        if (move.to.col == 7 && move.to.row == 0) wK = false
        if (move.to.col == 0 && move.to.row == 7) bQ = false
        if (move.to.col == 7 && move.to.row == 7) bK = false

        newBoard.castlingRights = CastlingRights(wK, wQ, bK, bQ)

        // Update En Passant target
        if (p.type == PieceType.PAWN && Math.abs(move.to.row - move.from.row) == 2) {
            val epRow = (move.from.row + move.to.row) / 2
            newBoard.enPassantTarget = Square(move.from.col, epRow)
        } else {
            newBoard.enPassantTarget = null
        }

        // Update Halfmove clock (resets on pawn move or capture)
        if (p.type == PieceType.PAWN || move.capturedPiece != null) {
            newBoard.halfmoveClock = 0
        } else {
            newBoard.halfmoveClock++
        }

        // Fullmove number
        if (board.turn == PieceColor.BLACK) {
            newBoard.fullmoveNumber++
        }

        // Switch turn
        newBoard.turn = board.turn.opposite()

        return newBoard
    }

    fun getLegalMoves(board: ChessBoard, color: PieceColor): List<Move> {
        val pseudoMoves = generatePseudoLegalMoves(board, color)
        val legalMoves = mutableListOf<Move>()

        for (m in pseudoMoves) {
            val afterBoard = applyMove(board, m)
            // If the king of the moving color is in check after the move, it's illegal
            if (!isKingInCheck(afterBoard, color)) {
                legalMoves.add(m)
            }
        }
        return legalMoves
    }

    fun getLegalMovesForSquare(board: ChessBoard, square: Square): List<Move> {
        val piece = board.getPiece(square) ?: return emptyList()
        if (piece.color != board.turn) return emptyList()
        return getLegalMoves(board, board.turn).filter { it.from == square }
    }

    fun generateSan(board: ChessBoard, move: Move): String {
        if (move.isKingsideCastle) return "O-O"
        if (move.isQueensideCastle) return "O-O-O"

        val sb = StringBuilder()
        val piece = move.piece
        val isCapture = move.capturedPiece != null || move.isEnPassant

        if (piece.type != PieceType.PAWN) {
            sb.append(piece.type.sanLetter)

            // Disambiguation
            val allLegal = getLegalMoves(board, piece.color).filter {
                it.to == move.to && it.piece.type == piece.type && it.from != move.from
            }
            if (allLegal.isNotEmpty()) {
                val sameCol = allLegal.any { it.from.col == move.from.col }
                val sameRow = allLegal.any { it.from.row == move.from.row }
                if (!sameCol) {
                    sb.append(('a' + move.from.col))
                } else if (!sameRow) {
                    sb.append(move.from.row + 1)
                } else {
                    sb.append(move.from.algebraic)
                }
            }
        } else {
            if (isCapture) {
                sb.append(('a' + move.from.col))
            }
        }

        if (isCapture) {
            sb.append('x')
        }

        sb.append(move.to.algebraic)

        if (move.promotion != null) {
            sb.append('=').append(move.promotion.sanLetter)
        }

        val afterBoard = applyMove(board, move)
        val opponentColor = piece.color.opposite()
        val opponentInCheck = isKingInCheck(afterBoard, opponentColor)
        val opponentLegalMoves = getLegalMoves(afterBoard, opponentColor)

        if (opponentInCheck) {
            if (opponentLegalMoves.isEmpty()) {
                sb.append('#')
            } else {
                sb.append('+')
            }
        }

        return sb.toString()
    }

    fun isInsufficientMaterial(board: ChessBoard): Boolean {
        val pieces = board.getAllPieces().map { it.second }
        if (pieces.size == 2) {
            // King vs King
            return true
        }
        if (pieces.size == 3) {
            val nonKings = pieces.filter { it.type != PieceType.KING }
            if (nonKings.size == 1) {
                val piece = nonKings[0]
                if (piece.type == PieceType.BISHOP || piece.type == PieceType.KNIGHT) {
                    // King + Bishop vs King OR King + Knight vs King
                    return true
                }
            }
        }
        if (pieces.size == 4) {
            val bishops = board.getAllPieces().filter { it.second.type == PieceType.BISHOP }
            if (bishops.size == 2 && pieces.count { it.type == PieceType.KING } == 2) {
                val b1 = bishops[0]
                val b2 = bishops[1]
                if (b1.second.color != b2.second.color) {
                    // Check if bishops are on the same color square
                    if (b1.first.isLight == b2.first.isLight) {
                        return true
                    }
                }
            }
        }
        return false
    }

    fun checkGameStatus(board: ChessBoard, positionHistory: List<String>): GameStatus {
        val legalMoves = getLegalMoves(board, board.turn)
        val inCheck = isKingInCheck(board, board.turn)

        if (legalMoves.isEmpty()) {
            return if (inCheck) {
                if (board.turn == PieceColor.WHITE) GameStatus.CHECKMATE_BLACK_WINS else GameStatus.CHECKMATE_WHITE_WINS
            } else {
                GameStatus.STALEMATE
            }
        }

        if (isInsufficientMaterial(board)) {
            return GameStatus.DRAW_INSUFFICIENT_MATERIAL
        }

        if (board.halfmoveClock >= 100) {
            return GameStatus.DRAW_FIFTY_MOVES
        }

        val currentKey = board.getPositionKey()
        val count = positionHistory.count { it == currentKey }
        if (count >= 3) {
            return GameStatus.DRAW_THREEFOLD_REPETITION
        }

        return GameStatus.IN_PROGRESS
    }
}
