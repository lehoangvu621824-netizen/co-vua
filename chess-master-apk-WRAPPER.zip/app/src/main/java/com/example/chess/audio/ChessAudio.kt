package com.example.chess.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

enum class ChessSoundEffect {
    MOVE,
    CAPTURE,
    CHECK,
    CASTLE,
    PROMOTION,
    GAME_OVER,
    ILLEGAL
}

class ChessAudio(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var isSoundEnabled: Boolean = true
    var isVibrationEnabled: Boolean = true

    fun play(effect: ChessSoundEffect) {
        if (isVibrationEnabled) {
            triggerVibration(effect)
        }
        if (isSoundEnabled) {
            scope.launch {
                generateAndPlayTone(effect)
            }
        }
    }

    private fun triggerVibration(effect: ChessSoundEffect) {
        try {
            if (vibrator == null || !vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val vibrationEffect = when (effect) {
                    ChessSoundEffect.MOVE -> VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE)
                    ChessSoundEffect.CAPTURE -> VibrationEffect.createOneShot(40, 200)
                    ChessSoundEffect.CHECK -> VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 30), -1)
                    ChessSoundEffect.CASTLE -> VibrationEffect.createWaveform(longArrayOf(0, 20, 30, 20), -1)
                    ChessSoundEffect.PROMOTION -> VibrationEffect.createWaveform(longArrayOf(0, 40, 30, 50), -1)
                    ChessSoundEffect.GAME_OVER -> VibrationEffect.createWaveform(longArrayOf(0, 80, 50, 80), -1)
                    ChessSoundEffect.ILLEGAL -> VibrationEffect.createOneShot(50, 100)
                }
                vibrator.vibrate(vibrationEffect)
            } else {
                @Suppress("DEPRECATION")
                when (effect) {
                    ChessSoundEffect.MOVE -> vibrator.vibrate(20)
                    ChessSoundEffect.CAPTURE -> vibrator.vibrate(45)
                    ChessSoundEffect.CHECK, ChessSoundEffect.GAME_OVER -> vibrator.vibrate(100)
                    else -> vibrator.vibrate(30)
                }
            }
        } catch (e: Exception) {
            // Ignore vibration exceptions on unusual hardware
        }
    }

    private fun generateAndPlayTone(effect: ChessSoundEffect) {
        try {
            val sampleRate = 44100
            val frequencies: List<Pair<Double, Int>> = when (effect) {
                ChessSoundEffect.MOVE -> listOf(Pair(440.0, 40), Pair(330.0, 30))
                ChessSoundEffect.CAPTURE -> listOf(Pair(220.0, 60), Pair(180.0, 50), Pair(140.0, 40))
                ChessSoundEffect.CHECK -> listOf(Pair(587.33, 70), Pair(880.0, 100))
                ChessSoundEffect.CASTLE -> listOf(Pair(392.0, 40), Pair(523.25, 45))
                ChessSoundEffect.PROMOTION -> listOf(Pair(440.0, 50), Pair(554.37, 60), Pair(659.25, 90))
                ChessSoundEffect.GAME_OVER -> listOf(Pair(440.0, 80), Pair(554.37, 80), Pair(659.25, 80), Pair(880.0, 150))
                ChessSoundEffect.ILLEGAL -> listOf(Pair(160.0, 80))
            }

            val totalDurationMs = frequencies.sumOf { it.second }
            val numSamples = (sampleRate * totalDurationMs / 1000.0).toInt()
            val sampleBuffer = ShortArray(numSamples)

            var sampleOffset = 0
            for ((freq, durationMs) in frequencies) {
                val segSamples = (sampleRate * durationMs / 1000.0).toInt()
                for (i in 0 until segSamples) {
                    val progress = i.toDouble() / segSamples
                    // Envelope (attack and exponential decay)
                    val envelope = if (progress < 0.1) {
                        progress / 0.1
                    } else {
                        Math.exp(-4.0 * (progress - 0.1))
                    }
                    val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                    val sample = (sin(angle) * Short.MAX_VALUE * 0.4 * envelope).toInt().toShort()
                    if (sampleOffset + i < sampleBuffer.size) {
                        sampleBuffer[sampleOffset + i] = sample
                    }
                }
                sampleOffset += segSamples
            }

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(sampleBuffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(sampleBuffer, 0, sampleBuffer.size)
            audioTrack.play()

            // Release track after playback
            Thread.sleep(totalDurationMs.toLong() + 20)
            audioTrack.stop()
            audioTrack.release()
        } catch (e: Exception) {
            // AudioTrack creation or playback fallback
        }
    }
}
