package com.example.chess.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_history")
data class GameEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mode: String,
    val difficulty: String,
    val playerColor: String,
    val opponentName: String,
    val result: String,
    val totalMoves: Int,
    val movesPgn: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0
)
