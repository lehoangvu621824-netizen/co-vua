package com.example.chess.engine

import com.example.chess.model.*

class ChessBoard private constructor(
    private val squares: Array<Array<Piece?>>,
    var turn: PieceColor = PieceColor.WHITE,
    var castlingRights: CastlingRights = CastlingRights(),
    var enPassantTarget: Square? = null,
    var halfmoveClock: Int = 0,
    var fullmoveNumber: Int = 1
) {
    constructor() : this(
        squares = Array(8) { Array(8) { null } },
        turn = PieceColor.WHITE,
        castlingRights = CastlingRights(),
        enPassantTarget = null,
        halfmoveClock = 0,
        fullmoveNumber = 1
    ) {
        setupInitialPosition()
    }

    fun getPiece(square: Square): Piece? = squares[square.row][square.col]
    fun getPiece(col: Int, row: Int): Piece? = squares[row][col]

    fun setPiece(square: Square, piece: Piece?) {
        squares[square.row][square.col] = piece
    }

    fun setPiece(col: Int, row: Int, piece: Piece?) {
        squares[row][col] = piece
    }

    fun copy(): ChessBoard {
        val newSquares = Array(8) { r ->
            Array(8) { c ->
                squares[r][c]
            }
        }
        return ChessBoard(
            squares = newSquares,
            turn = this.turn,
            castlingRights = this.castlingRights.copy(),
            enPassantTarget = this.enPassantTarget,
            halfmoveClock = this.halfmoveClock,
            fullmoveNumber = this.fullmoveNumber
        )
    }

    fun setupInitialPosition() {
        for (r in 0..7) {
            for (c in 0..7) {
                squares[r][c] = null
            }
        }
        // White Pawns
        for (c in 0..7) squares[1][c] = Piece(PieceType.PAWN, PieceColor.WHITE)
        // White Major/Minor pieces
        squares[0][0] = Piece(PieceType.ROOK, PieceColor.WHITE)
        squares[0][1] = Piece(PieceType.KNIGHT, PieceColor.WHITE)
        squares[0][2] = Piece(PieceType.BISHOP, PieceColor.WHITE)
        squares[0][3] = Piece(PieceType.QUEEN, PieceColor.WHITE)
        squares[0][4] = Piece(PieceType.KING, PieceColor.WHITE)
        squares[0][5] = Piece(PieceType.BISHOP, PieceColor.WHITE)
        squares[0][6] = Piece(PieceType.KNIGHT, PieceColor.WHITE)
        squares[0][7] = Piece(PieceType.ROOK, PieceColor.WHITE)

        // Black Pawns
        for (c in 0..7) squares[6][c] = Piece(PieceType.PAWN, PieceColor.BLACK)
        // Black Major/Minor pieces
        squares[7][0] = Piece(PieceType.ROOK, PieceColor.BLACK)
        squares[7][1] = Piece(PieceType.KNIGHT, PieceColor.BLACK)
        squares[7][2] = Piece(PieceType.BISHOP, PieceColor.BLACK)
        squares[7][3] = Piece(PieceType.QUEEN, PieceColor.BLACK)
        squares[7][4] = Piece(PieceType.KING, PieceColor.BLACK)
        squares[7][5] = Piece(PieceType.BISHOP, PieceColor.BLACK)
        squares[7][6] = Piece(PieceType.KNIGHT, PieceColor.BLACK)
        squares[7][7] = Piece(PieceType.ROOK, PieceColor.BLACK)

        turn = PieceColor.WHITE
        castlingRights = CastlingRights()
        enPassantTarget = null
        halfmoveClock = 0
        fullmoveNumber = 1
    }

    fun findKing(color: PieceColor): Square? {
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = squares[r][c]
                if (piece != null && piece.color == color && piece.type == PieceType.KING) {
                    return Square(c, r)
                }
            }
        }
        return null
    }

    fun getAllPieces(): List<Pair<Square, Piece>> {
        val list = mutableListOf<Pair<Square, Piece>>()
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = squares[r][c]
                if (piece != null) {
                    list.add(Pair(Square(c, r), piece))
                }
            }
        }
        return list
    }

    fun toFen(): String {
        val sb = StringBuilder()
        // 1. Piece placement
        for (r in 7 downTo 0) {
            var emptyCount = 0
            for (c in 0..7) {
                val p = squares[r][c]
                if (p == null) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    sb.append(p.fenChar)
                }
            }
            if (emptyCount > 0) {
                sb.append(emptyCount)
            }
            if (r > 0) sb.append('/')
        }

        // 2. Active color
        sb.append(' ')
        sb.append(if (turn == PieceColor.WHITE) 'w' else 'b')

        // 3. Castling availability
        sb.append(' ')
        sb.append(castlingRights.toFenString())

        // 4. En passant target
        sb.append(' ')
        sb.append(enPassantTarget?.algebraic ?: "-")

        // 5. Halfmove clock
        sb.append(' ')
        sb.append(halfmoveClock)

        // 6. Fullmove number
        sb.append(' ')
        sb.append(fullmoveNumber)

        return sb.toString()
    }

    fun getPositionKey(): String {
        // Generates key for threefold repetition (board + turn + castling + ep)
        val sb = StringBuilder()
        for (r in 0..7) {
            for (c in 0..7) {
                val p = squares[r][c]
                sb.append(p?.fenChar ?: '.')
            }
        }
        sb.append('|').append(turn).append('|').append(castlingRights.toFenString())
        sb.append('|').append(enPassantTarget?.algebraic ?: "-")
        return sb.toString()
    }

    companion object {
        fun fromFen(fen: String): ChessBoard {
            val board = ChessBoard()
            for (r in 0..7) {
                for (c in 0..7) {
                    board.squares[r][c] = null
                }
            }

            val parts = fen.trim().split("\\s+".toRegex())
            if (parts.isEmpty()) return board

            // Piece placement
            val rows = parts[0].split('/')
            for (i in rows.indices) {
                val r = 7 - i
                if (r !in 0..7) continue
                var c = 0
                for (ch in rows[i]) {
                    if (ch.isDigit()) {
                        c += ch.digitToInt()
                    } else {
                        val color = if (ch.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
                        val type = when (ch.uppercaseChar()) {
                            'P' -> PieceType.PAWN
                            'N' -> PieceType.KNIGHT
                            'B' -> PieceType.BISHOP
                            'R' -> PieceType.ROOK
                            'Q' -> PieceType.QUEEN
                            'K' -> PieceType.KING
                            else -> PieceType.PAWN
                        }
                        if (c in 0..7) {
                            board.squares[r][c] = Piece(type, color)
                        }
                        c++
                    }
                }
            }

            // Active turn
            if (parts.size > 1) {
                board.turn = if (parts[1] == "b") PieceColor.BLACK else PieceColor.WHITE
            }

            // Castling rights
            if (parts.size > 2) {
                board.castlingRights = CastlingRights.fromFen(parts[2])
            }

            // En passant target
            if (parts.size > 3 && parts[3] != "-") {
                try {
                    board.enPassantTarget = Square.fromAlgebraic(parts[3])
                } catch (e: Exception) {
                    board.enPassantTarget = null
                }
            }

            // Halfmove clock
            if (parts.size > 4) {
                board.halfmoveClock = parts[4].toIntOrNull() ?: 0
            }

            // Fullmove number
            if (parts.size > 5) {
                board.fullmoveNumber = parts[5].toIntOrNull() ?: 1
            }

            return board
        }
    }
}
