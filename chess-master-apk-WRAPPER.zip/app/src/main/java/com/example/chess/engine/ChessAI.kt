package com.example.chess.engine

import com.example.chess.model.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object ChessAI {

    private val PAWN_TABLE = intArrayOf(
        0,  0,  0,  0,  0,  0,  0,  0,
        50, 50, 50, 50, 50, 50, 50, 50,
        10, 10, 20, 30, 30, 20, 10, 10,
        5,  5, 10, 25, 25, 10,  5,  5,
        0,  0,  0, 20, 20,  0,  0,  0,
        5, -5,-10,  0,  0,-10, -5,  5,
        5, 10, 10,-20,-20, 10, 10,  5,
        0,  0,  0,  0,  0,  0,  0,  0
    )

    private val KNIGHT_TABLE = intArrayOf(
        -50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50
    )

    private val BISHOP_TABLE = intArrayOf(
        -20,-10,-10,-10,-10,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5, 10, 10,  5,  0,-10,
        -10,  5,  5, 10, 10,  5,  5,-10,
        -10,  0, 10, 10, 10, 10,  0,-10,
        -10, 10, 10, 10, 10, 10, 10,-10,
        -10,  5,  0,  0,  0,  0,  5,-10,
        -20,-10,-10,-10,-10,-10,-10,-20
    )

    private val ROOK_TABLE = intArrayOf(
        0,  0,  0,  0,  0,  0,  0,  0,
        5, 10, 10, 10, 10, 10, 10,  5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        0,  0,  0,  5,  5,  0,  0,  0
    )

    private val QUEEN_TABLE = intArrayOf(
        -20,-10,-10, -5, -5,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5,  5,  5,  5,  0,-10,
        -5,  0,  5,  5,  5,  5,  0, -5,
        0,  0,  5,  5,  5,  5,  0, -5,
        -10,  5,  5,  5,  5,  5,  0,-10,
        -10,  0,  5,  0,  0,  0,  0,-10,
        -20,-10,-10, -5, -5,-10,-10,-20
    )

    private val KING_MIDDLE_TABLE = intArrayOf(
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -20,-30,-30,-40,-40,-30,-30,-20,
        -10,-20,-20,-20,-20,-20,-20,-10,
        20, 20,  0,  0,  0,  0, 20, 20,
        20, 30, 10,  0,  0, 10, 30, 20
    )

    private val KING_END_TABLE = intArrayOf(
        -50,-40,-30,-20,-20,-30,-40,-50,
        -30,-20,-10,  0,  0,-10,-20,-30,
        -30,-10, 20, 30, 30, 20,-10,-30,
        -30,-10, 30, 40, 40, 30,-10,-30,
        -30,-10, 30, 40, 40, 30,-10,-30,
        -30,-10, 20, 30, 30, 20,-10,-30,
        -30,-30,  0,  0,  0,  0,-30,-30,
        -50,-30,-30,-30,-30,-30,-30,-50
    )

    fun evaluateBoard(board: ChessBoard): Int {
        var whiteScore = 0
        var blackScore = 0

        var pieceCount = 0
        val allPieces = board.getAllPieces()

        for ((_, piece) in allPieces) {
            if (piece.type != PieceType.KING && piece.type != PieceType.PAWN) {
                pieceCount++
            }
        }
        val isEndgame = pieceCount <= 6

        for ((sq, piece) in allPieces) {
            val baseVal = piece.type.baseValue
            val tableIndex = if (piece.color == PieceColor.WHITE) {
                (7 - sq.row) * 8 + sq.col
            } else {
                sq.row * 8 + sq.col
            }

            val posVal = when (piece.type) {
                PieceType.PAWN -> PAWN_TABLE[tableIndex]
                PieceType.KNIGHT -> KNIGHT_TABLE[tableIndex]
                PieceType.BISHOP -> BISHOP_TABLE[tableIndex]
                PieceType.ROOK -> ROOK_TABLE[tableIndex]
                PieceType.QUEEN -> QUEEN_TABLE[tableIndex]
                PieceType.KING -> if (isEndgame) KING_END_TABLE[tableIndex] else KING_MIDDLE_TABLE[tableIndex]
            }

            val total = baseVal + posVal
            if (piece.color == PieceColor.WHITE) {
                whiteScore += total
            } else {
                blackScore += total
            }
        }

        return whiteScore - blackScore
    }

    private fun scoreMove(move: Move): Int {
        var score = 0
        if (move.capturedPiece != null) {
            // MVV-LVA (Most Valuable Victim - Least Valuable Attacker)
            score += 10000 + (move.capturedPiece.type.baseValue * 10) - move.piece.type.baseValue
        }
        if (move.promotion != null) {
            score += 9000 + move.promotion.baseValue
        }
        if (move.isCastling) {
            score += 500
        }
        return score
    }

    private fun orderMoves(moves: List<Move>): List<Move> {
        return moves.sortedByDescending { scoreMove(it) }
    }

    private fun quiescence(board: ChessBoard, mutAlpha: Int, beta: Int, isMaximizing: Boolean): Int {
        var alpha = mutAlpha
        val standPat = evaluateBoard(board)

        if (isMaximizing) {
            if (standPat >= beta) return beta
            if (standPat > alpha) alpha = standPat

            val captures = ChessRules.getLegalMoves(board, PieceColor.WHITE)
                .filter { it.capturedPiece != null || it.promotion != null }
            val ordered = orderMoves(captures)

            for (move in ordered) {
                val nextBoard = ChessRules.applyMove(board, move)
                val score = quiescence(nextBoard, alpha, beta, false)
                if (score >= beta) return beta
                if (score > alpha) alpha = score
            }
            return alpha
        } else {
            if (standPat <= alpha) return alpha
            var newBeta = beta
            if (standPat < newBeta) newBeta = standPat

            val captures = ChessRules.getLegalMoves(board, PieceColor.BLACK)
                .filter { it.capturedPiece != null || it.promotion != null }
            val ordered = orderMoves(captures)

            for (move in ordered) {
                val nextBoard = ChessRules.applyMove(board, move)
                val score = quiescence(nextBoard, alpha, newBeta, true)
                if (score <= alpha) return alpha
                if (score < newBeta) newBeta = score
            }
            return newBeta
        }
    }

    private fun minimax(
        board: ChessBoard,
        depth: Int,
        mutAlpha: Int,
        beta: Int,
        isMaximizing: Boolean,
        useQuiescence: Boolean = false
    ): Int {
        var alpha = mutAlpha
        val legalMoves = ChessRules.getLegalMoves(board, if (isMaximizing) PieceColor.WHITE else PieceColor.BLACK)

        if (legalMoves.isEmpty()) {
            val inCheck = ChessRules.isKingInCheck(board, if (isMaximizing) PieceColor.WHITE else PieceColor.BLACK)
            return if (inCheck) {
                if (isMaximizing) -100000 - depth else 100000 + depth
            } else {
                0 // Draw / Stalemate
            }
        }

        if (depth == 0) {
            return if (useQuiescence) {
                quiescence(board, alpha, beta, isMaximizing)
            } else {
                evaluateBoard(board)
            }
        }

        val orderedMoves = orderMoves(legalMoves)

        if (isMaximizing) {
            var maxEval = Int.MIN_VALUE
            for (move in orderedMoves) {
                val nextBoard = ChessRules.applyMove(board, move)
                val eval = minimax(nextBoard, depth - 1, alpha, beta, false, useQuiescence)
                maxEval = max(maxEval, eval)
                alpha = max(alpha, eval)
                if (beta <= alpha) break
            }
            return maxEval
        } else {
            var minEval = Int.MAX_VALUE
            var currentBeta = beta
            for (move in orderedMoves) {
                val nextBoard = ChessRules.applyMove(board, move)
                val eval = minimax(nextBoard, depth - 1, alpha, currentBeta, true, useQuiescence)
                minEval = min(minEval, eval)
                currentBeta = min(currentBeta, eval)
                if (currentBeta <= alpha) break
            }
            return minEval
        }
    }

    fun findBestMove(
        board: ChessBoard,
        difficulty: AIDifficulty
    ): Move? {
        val legalMoves = ChessRules.getLegalMoves(board, board.turn)
        if (legalMoves.isEmpty()) return null

        val isWhite = board.turn == PieceColor.WHITE

        // Easy Mode: Pick a random move among top moves or random 35% of time
        if (difficulty == AIDifficulty.EASY) {
            if (Random.nextFloat() < 0.40f) {
                return legalMoves.random()
            }
            val scored = legalMoves.map { move ->
                val nextBoard = ChessRules.applyMove(board, move)
                val eval = evaluateBoard(nextBoard)
                Pair(move, if (isWhite) eval else -eval)
            }.sortedByDescending { it.second }
            val topPool = scored.take(min(3, scored.size))
            return topPool.random().first
        }

        val searchDepth = difficulty.searchDepth
        val useQuiescence = difficulty == AIDifficulty.MASTER

        val orderedMoves = orderMoves(legalMoves)
        var bestMove: Move = orderedMoves.first()
        var bestVal = if (isWhite) Int.MIN_VALUE else Int.MAX_VALUE

        val scoredMoves = mutableListOf<Pair<Move, Int>>()

        var alpha = Int.MIN_VALUE
        var beta = Int.MAX_VALUE

        for (move in orderedMoves) {
            val nextBoard = ChessRules.applyMove(board, move)
            val eval = minimax(
                nextBoard,
                searchDepth - 1,
                alpha,
                beta,
                !isWhite,
                useQuiescence
            )

            scoredMoves.add(Pair(move, eval))

            if (isWhite) {
                if (eval > bestVal) {
                    bestVal = eval
                    bestMove = move
                }
                alpha = max(alpha, eval)
            } else {
                if (eval < bestVal) {
                    bestVal = eval
                    bestMove = move
                }
                beta = min(beta, eval)
            }
        }

        // Medium mode: small chance to pick 2nd best move
        if (difficulty == AIDifficulty.MEDIUM && scoredMoves.size > 1) {
            val sorted = if (isWhite) {
                scoredMoves.sortedByDescending { it.second }
            } else {
                scoredMoves.sortedBy { it.second }
            }
            if (Random.nextFloat() < 0.25f && sorted.size >= 2) {
                return sorted[1].first
            }
            return sorted[0].first
        }

        return bestMove
    }

    fun getMaterialAdvantage(board: ChessBoard): Pair<Int, Map<PieceType, Int>> {
        var whiteSum = 0
        var blackSum = 0

        val whiteCounts = mutableMapOf<PieceType, Int>()
        val blackCounts = mutableMapOf<PieceType, Int>()

        for ((_, piece) in board.getAllPieces()) {
            if (piece.type == PieceType.KING) continue
            if (piece.color == PieceColor.WHITE) {
                whiteSum += piece.type.baseValue / 100
                whiteCounts[piece.type] = (whiteCounts[piece.type] ?: 0) + 1
            } else {
                blackSum += piece.type.baseValue / 100
                blackCounts[piece.type] = (blackCounts[piece.type] ?: 0) + 1
            }
        }

        val diff = whiteSum - blackSum
        // Compute captured pieces relative to initial setup
        val capturedByWhite = mutableMapOf<PieceType, Int>()
        val capturedByBlack = mutableMapOf<PieceType, Int>()

        val initialCounts = mapOf(
            PieceType.PAWN to 8,
            PieceType.KNIGHT to 2,
            PieceType.BISHOP to 2,
            PieceType.ROOK to 2,
            PieceType.QUEEN to 1
        )

        initialCounts.forEach { (type, count) ->
            val wHas = whiteCounts[type] ?: 0
            val bHas = blackCounts[type] ?: 0
            if (count > bHas) capturedByWhite[type] = count - bHas
            if (count > wHas) capturedByBlack[type] = count - wHas
        }

        return Pair(diff, if (diff >= 0) capturedByWhite else capturedByBlack)
    }
}
