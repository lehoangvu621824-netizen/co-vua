package com.example.chess.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.engine.ChessBoard
import com.example.chess.model.Move
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.ui.theme.BoardTheme

@Composable
fun ChessBoardView(
    board: ChessBoard,
    isFlipped: Boolean,
    boardTheme: BoardTheme,
    selectedSquare: Square?,
    legalMoves: List<Move>,
    lastMove: Move?,
    kingInCheckSquare: Square?,
    hintMove: Move?,
    onSquareClicked: (Square) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(6.dp)
            .shadow(12.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(boardTheme.darkSquare)
            .border(3.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .testTag("chess_board_view")
    ) {
        val squareSize = maxWidth / 8

        Column(modifier = Modifier.fillMaxSize()) {
            val rows = if (isFlipped) (0..7) else (7 downTo 0)
            val cols = if (isFlipped) (7 downTo 0) else (0..7)

            for (r in rows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(squareSize)
                ) {
                    for (c in cols) {
                        val square = Square(c, r)
                        val piece = board.getPiece(square)
                        val isLight = square.isLight

                        // Base square color
                        val baseColor = if (isLight) boardTheme.lightSquare else boardTheme.darkSquare
                        val coordTextColor = if (isLight) boardTheme.darkSquare.copy(alpha = 0.85f) else boardTheme.lightSquare.copy(alpha = 0.85f)

                        // Highlight calculations
                        val isSelected = selectedSquare == square
                        val isLastMove = lastMove != null && (lastMove.from == square || lastMove.to == square)
                        val isCheck = kingInCheckSquare == square
                        val isHint = hintMove != null && (hintMove.from == square || hintMove.to == square)
                        val moveTarget = legalMoves.find { it.to == square }
                        val isLegalTarget = moveTarget != null

                        val finalBgColor = when {
                            isCheck -> boardTheme.checkAlert
                            isSelected -> boardTheme.highlightSelected
                            isHint -> Color(0xAA00E5FF)
                            isLastMove -> boardTheme.highlightLastMove
                            else -> baseColor
                        }

                        Box(
                            modifier = Modifier
                                .width(squareSize)
                                .height(squareSize)
                                .background(finalBgColor)
                                .clickable { onSquareClicked(square) }
                                .testTag("square_${square.algebraic}"),
                            contentAlignment = Alignment.Center
                        ) {
                            // Coordinate Labels
                            val showRankLabel = if (isFlipped) c == 7 else c == 0
                            val showFileLabel = if (isFlipped) r == 7 else r == 0

                            if (showRankLabel) {
                                Text(
                                    text = "${r + 1}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = coordTextColor,
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(start = 3.dp, top = 2.dp)
                                )
                            }
                            if (showFileLabel) {
                                Text(
                                    text = "${('a' + c)}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = coordTextColor,
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(end = 3.dp, bottom = 2.dp)
                                )
                            }

                            // Piece Graphic
                            if (piece != null) {
                                ChessPieceView(
                                    piece = piece,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(squareSize * 0.08f)
                                )
                            }

                            // Legal Move Marker
                            if (isLegalTarget) {
                                if (piece != null || moveTarget?.isEnPassant == true) {
                                    // Capture ring
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(squareSize * 0.08f)
                                            .border(
                                                width = (squareSize * 0.09f),
                                                color = boardTheme.highlightLegalMove,
                                                shape = CircleShape
                                            )
                                    )
                                } else {
                                    // Move destination dot
                                    Box(
                                        modifier = Modifier
                                            .size(squareSize * 0.32f)
                                            .clip(CircleShape)
                                            .background(boardTheme.highlightLegalMove)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
