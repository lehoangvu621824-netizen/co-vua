package com.example.chess.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chess.audio.ChessAudio
import com.example.chess.audio.ChessSoundEffect
import com.example.chess.data.ChessPuzzle
import com.example.chess.data.PuzzleRepository
import com.example.chess.data.db.ChessDatabase
import com.example.chess.data.db.GameEntity
import com.example.chess.engine.ChessAI
import com.example.chess.engine.ChessBoard
import com.example.chess.engine.ChessRules
import com.example.chess.model.*
import com.example.chess.ui.theme.BoardTheme
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

enum class PuzzleStatus {
    SOLVING,
    CORRECT_STEP,
    WRONG_MOVE,
    SOLVED
}

data class ChessUiState(
    val board: ChessBoard = ChessBoard(),
    val gameMode: GameMode = GameMode.VS_AI,
    val aiDifficulty: AIDifficulty = AIDifficulty.MEDIUM,
    val playerColor: PieceColor = PieceColor.WHITE,
    val isFlipped: Boolean = false,
    val selectedSquare: Square? = null,
    val legalMoves: List<Move> = emptyList(),
    val moveHistory: List<Move> = emptyList(),
    val lastMove: Move? = null,
    val hintMove: Move? = null,
    val kingInCheckSquare: Square? = null,
    val gameStatus: GameStatus = GameStatus.IN_PROGRESS,
    val isAiThinking: Boolean = false,
    val pendingPromotionFromTo: Pair<Square, Square>? = null,
    val boardTheme: BoardTheme = BoardTheme.WOOD,
    val timeControl: TimeControl = TimeControl.RAPID_10_0,
    val whiteTimeSeconds: Int? = 600,
    val blackTimeSeconds: Int? = 600,
    val isTimerActive: Boolean = false,
    val isSoundEnabled: Boolean = true,
    val isVibrationEnabled: Boolean = true,
    // Puzzles
    val currentPuzzleIndex: Int = 0,
    val puzzleStatus: PuzzleStatus = PuzzleStatus.SOLVING,
    val puzzleStepIndex: Int = 0,
    val showPuzzleHint: Boolean = false,
    // Statistics
    val matchHistory: List<GameEntity> = emptyList()
)

class ChessViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ChessDatabase.getDatabase(application)
    private val gameDao = db.gameDao()
    private val audio = ChessAudio(application)

    private val _uiState = MutableStateFlow(ChessUiState())
    val uiState: StateFlow<ChessUiState> = _uiState.asStateFlow()

    private val boardStack = mutableListOf<ChessBoard>()
    private val positionHistory = mutableListOf<String>()
    private var timerJob: Job? = null
    private var aiJob: Job? = null

    init {
        // Collect DB match history
        viewModelScope.launch {
            gameDao.getAllGames().collect { list ->
                _uiState.update { it.copy(matchHistory = list) }
            }
        }
        startNewGame()
    }

    fun setGameMode(mode: GameMode) {
        if (_uiState.value.gameMode == mode) return
        _uiState.update { it.copy(gameMode = mode) }
        if (mode == GameMode.PUZZLES) {
            loadPuzzle(_uiState.value.currentPuzzleIndex)
        } else if (mode != GameMode.CHESS_CLOCK) {
            startNewGame()
        }
    }

    fun setAIDifficulty(difficulty: AIDifficulty) {
        _uiState.update { it.copy(aiDifficulty = difficulty) }
    }

    fun setBoardTheme(theme: BoardTheme) {
        _uiState.update { it.copy(boardTheme = theme) }
    }

    fun setPlayerColor(color: PieceColor) {
        _uiState.update { it.copy(playerColor = color, isFlipped = (color == PieceColor.BLACK)) }
        startNewGame()
    }

    fun setTimeControl(tc: TimeControl) {
        _uiState.update {
            it.copy(
                timeControl = tc,
                whiteTimeSeconds = if (tc.initialSeconds > 0) tc.initialSeconds else null,
                blackTimeSeconds = if (tc.initialSeconds > 0) tc.initialSeconds else null
            )
        }
    }

    fun toggleFlipBoard() {
        _uiState.update { it.copy(isFlipped = !it.isFlipped) }
    }

    fun toggleSound() {
        val next = !_uiState.value.isSoundEnabled
        audio.isSoundEnabled = next
        _uiState.update { it.copy(isSoundEnabled = next) }
    }

    fun toggleVibration() {
        val next = !_uiState.value.isVibrationEnabled
        audio.isVibrationEnabled = next
        _uiState.update { it.copy(isVibrationEnabled = next) }
    }

    fun startNewGame() {
        timerJob?.cancel()
        aiJob?.cancel()

        val newBoard = ChessBoard()
        boardStack.clear()
        boardStack.add(newBoard.copy())
        positionHistory.clear()
        positionHistory.add(newBoard.getPositionKey())

        val tc = _uiState.value.timeControl
        val initialTime = if (tc.initialSeconds > 0) tc.initialSeconds else null

        _uiState.update {
            it.copy(
                board = newBoard,
                selectedSquare = null,
                legalMoves = emptyList(),
                moveHistory = emptyList(),
                lastMove = null,
                hintMove = null,
                kingInCheckSquare = null,
                gameStatus = GameStatus.IN_PROGRESS,
                isAiThinking = false,
                pendingPromotionFromTo = null,
                whiteTimeSeconds = initialTime,
                blackTimeSeconds = initialTime,
                isTimerActive = (initialTime != null)
            )
        }

        if (initialTime != null) {
            startTimer()
        }

        // If AI plays White and player is Black
        if (_uiState.value.gameMode == GameMode.VS_AI && _uiState.value.playerColor == PieceColor.BLACK) {
            triggerAiMove(newBoard)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val state = _uiState.value
                if (state.gameStatus.isGameOver || !state.isTimerActive) break

                val isWhiteTurn = state.board.turn == PieceColor.WHITE
                if (isWhiteTurn && state.whiteTimeSeconds != null) {
                    val nextTime = state.whiteTimeSeconds - 1
                    if (nextTime <= 0) {
                        _uiState.update {
                            it.copy(whiteTimeSeconds = 0, gameStatus = GameStatus.WHITE_TIMEOUT)
                        }
                        audio.play(ChessSoundEffect.GAME_OVER)
                        saveGameToHistory(GameStatus.WHITE_TIMEOUT)
                        break
                    } else {
                        _uiState.update { it.copy(whiteTimeSeconds = nextTime) }
                    }
                } else if (!isWhiteTurn && state.blackTimeSeconds != null) {
                    val nextTime = state.blackTimeSeconds - 1
                    if (nextTime <= 0) {
                        _uiState.update {
                            it.copy(blackTimeSeconds = 0, gameStatus = GameStatus.BLACK_TIMEOUT)
                        }
                        audio.play(ChessSoundEffect.GAME_OVER)
                        saveGameToHistory(GameStatus.BLACK_TIMEOUT)
                        break
                    } else {
                        _uiState.update { it.copy(blackTimeSeconds = nextTime) }
                    }
                }
            }
        }
    }

    fun onSquareClicked(square: Square) {
        val state = _uiState.value
        if (state.gameStatus.isGameOver || state.isAiThinking) return

        // In puzzle mode
        if (state.gameMode == GameMode.PUZZLES) {
            handlePuzzleSquareClick(square)
            return
        }

        // In VS_AI mode: check if it's the player's turn
        if (state.gameMode == GameMode.VS_AI && state.board.turn != state.playerColor) {
            return
        }

        val board = state.board
        val currentPiece = board.getPiece(square)
        val selected = state.selectedSquare

        if (selected == null) {
            if (currentPiece != null && currentPiece.color == board.turn) {
                val legalMoves = ChessRules.getLegalMovesForSquare(board, square)
                _uiState.update { it.copy(selectedSquare = square, legalMoves = legalMoves, hintMove = null) }
            }
        } else {
            // Already selected a square
            val matchingMove = state.legalMoves.find { it.to == square }
            if (matchingMove != null) {
                // Check if move is a pawn promotion
                if (matchingMove.piece.type == PieceType.PAWN &&
                    (square.row == 7 || square.row == 0) &&
                    matchingMove.promotion != null
                ) {
                    _uiState.update {
                        it.copy(pendingPromotionFromTo = Pair(selected, square))
                    }
                } else {
                    executePlayerMove(matchingMove)
                }
            } else if (currentPiece != null && currentPiece.color == board.turn) {
                // Switch selection to another own piece
                val legalMoves = ChessRules.getLegalMovesForSquare(board, square)
                _uiState.update { it.copy(selectedSquare = square, legalMoves = legalMoves, hintMove = null) }
            } else {
                // Deselect
                _uiState.update { it.copy(selectedSquare = null, legalMoves = emptyList()) }
            }
        }
    }

    fun onPromotionSelected(promotionType: PieceType) {
        val state = _uiState.value
        val pair = state.pendingPromotionFromTo ?: return
        val matchingMove = state.legalMoves.find {
            it.from == pair.first && it.to == pair.second && it.promotion == promotionType
        } ?: state.legalMoves.find { it.from == pair.first && it.to == pair.second }

        _uiState.update { it.copy(pendingPromotionFromTo = null) }
        if (matchingMove != null) {
            val finalMove = matchingMove.copy(promotion = promotionType)
            executePlayerMove(finalMove)
        }
    }

    fun dismissPromotion() {
        _uiState.update { it.copy(pendingPromotionFromTo = null) }
    }

    private fun executePlayerMove(move: Move) {
        val currentBoard = _uiState.value.board
        val san = ChessRules.generateSan(currentBoard, move)
        val moveWithSan = move.copy(sanNotation = san)

        val nextBoard = ChessRules.applyMove(currentBoard, moveWithSan)
        boardStack.add(nextBoard.copy())
        val posKey = nextBoard.getPositionKey()
        positionHistory.add(posKey)

        // Increment clock if applicable
        val tc = _uiState.value.timeControl
        if (tc.incrementSeconds > 0) {
            if (currentBoard.turn == PieceColor.WHITE && _uiState.value.whiteTimeSeconds != null) {
                _uiState.update { it.copy(whiteTimeSeconds = it.whiteTimeSeconds!! + tc.incrementSeconds) }
            } else if (currentBoard.turn == PieceColor.BLACK && _uiState.value.blackTimeSeconds != null) {
                _uiState.update { it.copy(blackTimeSeconds = it.blackTimeSeconds!! + tc.incrementSeconds) }
            }
        }

        val status = ChessRules.checkGameStatus(nextBoard, positionHistory)
        val inCheck = ChessRules.isKingInCheck(nextBoard, nextBoard.turn)
        val checkSq = if (inCheck) nextBoard.findKing(nextBoard.turn) else null

        // Play Sound
        when {
            status.isGameOver -> audio.play(ChessSoundEffect.GAME_OVER)
            inCheck -> audio.play(ChessSoundEffect.CHECK)
            move.promotion != null -> audio.play(ChessSoundEffect.PROMOTION)
            move.isCastling -> audio.play(ChessSoundEffect.CASTLE)
            move.capturedPiece != null || move.isEnPassant -> audio.play(ChessSoundEffect.CAPTURE)
            else -> audio.play(ChessSoundEffect.MOVE)
        }

        val updatedMoveHistory = _uiState.value.moveHistory + moveWithSan

        _uiState.update {
            it.copy(
                board = nextBoard,
                selectedSquare = null,
                legalMoves = emptyList(),
                moveHistory = updatedMoveHistory,
                lastMove = moveWithSan,
                hintMove = null,
                kingInCheckSquare = checkSq,
                gameStatus = status
            )
        }

        if (status.isGameOver) {
            timerJob?.cancel()
            saveGameToHistory(status)
        } else if (_uiState.value.gameMode == GameMode.VS_AI && nextBoard.turn != _uiState.value.playerColor) {
            triggerAiMove(nextBoard)
        }
    }

    private fun triggerAiMove(board: ChessBoard) {
        _uiState.update { it.copy(isAiThinking = true) }
        aiJob?.cancel()
        aiJob = viewModelScope.launch(Dispatchers.Default) {
            // Natural thinking delay
            val delayMs = when (_uiState.value.aiDifficulty) {
                AIDifficulty.EASY -> 400L
                AIDifficulty.MEDIUM -> 600L
                AIDifficulty.HARD -> 900L
                AIDifficulty.MASTER -> 1200L
            }
            delay(delayMs)

            val bestMove = ChessAI.findBestMove(board, _uiState.value.aiDifficulty)

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(isAiThinking = false) }
                if (bestMove != null && !_uiState.value.gameStatus.isGameOver) {
                    val san = ChessRules.generateSan(board, bestMove)
                    val moveWithSan = bestMove.copy(sanNotation = san)
                    val nextBoard = ChessRules.applyMove(board, moveWithSan)

                    boardStack.add(nextBoard.copy())
                    positionHistory.add(nextBoard.getPositionKey())

                    // Increment clock if applicable
                    val tc = _uiState.value.timeControl
                    if (tc.incrementSeconds > 0 && board.turn == PieceColor.BLACK && _uiState.value.blackTimeSeconds != null) {
                        _uiState.update { it.copy(blackTimeSeconds = it.blackTimeSeconds!! + tc.incrementSeconds) }
                    }

                    val status = ChessRules.checkGameStatus(nextBoard, positionHistory)
                    val inCheck = ChessRules.isKingInCheck(nextBoard, nextBoard.turn)
                    val checkSq = if (inCheck) nextBoard.findKing(nextBoard.turn) else null

                    when {
                        status.isGameOver -> audio.play(ChessSoundEffect.GAME_OVER)
                        inCheck -> audio.play(ChessSoundEffect.CHECK)
                        moveWithSan.promotion != null -> audio.play(ChessSoundEffect.PROMOTION)
                        moveWithSan.isCastling -> audio.play(ChessSoundEffect.CASTLE)
                        moveWithSan.capturedPiece != null || moveWithSan.isEnPassant -> audio.play(ChessSoundEffect.CAPTURE)
                        else -> audio.play(ChessSoundEffect.MOVE)
                    }

                    val updatedMoves = _uiState.value.moveHistory + moveWithSan

                    _uiState.update {
                        it.copy(
                            board = nextBoard,
                            moveHistory = updatedMoves,
                            lastMove = moveWithSan,
                            kingInCheckSquare = checkSq,
                            gameStatus = status
                        )
                    }

                    if (status.isGameOver) {
                        timerJob?.cancel()
                        saveGameToHistory(status)
                    }
                }
            }
        }
    }

    fun undoMove() {
        if (boardStack.size <= 1 || _uiState.value.isAiThinking) return

        val movesToPop = if (_uiState.value.gameMode == GameMode.VS_AI) 2 else 1
        val actualPops = minOf(movesToPop, boardStack.size - 1)

        repeat(actualPops) {
            if (boardStack.size > 1) {
                boardStack.removeAt(boardStack.size - 1)
            }
            if (positionHistory.size > 1) {
                positionHistory.removeAt(positionHistory.size - 1)
            }
        }

        val previousBoard = boardStack.last().copy()
        val remainingMoves = _uiState.value.moveHistory.dropLast(actualPops)
        val inCheck = ChessRules.isKingInCheck(previousBoard, previousBoard.turn)
        val checkSq = if (inCheck) previousBoard.findKing(previousBoard.turn) else null

        _uiState.update {
            it.copy(
                board = previousBoard,
                selectedSquare = null,
                legalMoves = emptyList(),
                moveHistory = remainingMoves,
                lastMove = remainingMoves.lastOrNull(),
                hintMove = null,
                kingInCheckSquare = checkSq,
                gameStatus = GameStatus.IN_PROGRESS
            )
        }
        audio.play(ChessSoundEffect.MOVE)
    }

    fun requestHint() {
        val board = _uiState.value.board
        if (_uiState.value.gameStatus.isGameOver) return

        viewModelScope.launch(Dispatchers.Default) {
            val hint = ChessAI.findBestMove(board, AIDifficulty.MASTER)
            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(hintMove = hint) }
            }
        }
    }

    fun resignGame() {
        val currentTurn = _uiState.value.board.turn
        val status = if (currentTurn == PieceColor.WHITE) GameStatus.WHITE_RESIGNED else GameStatus.BLACK_RESIGNED
        _uiState.update { it.copy(gameStatus = status) }
        audio.play(ChessSoundEffect.GAME_OVER)
        saveGameToHistory(status)
    }

    fun offerDraw() {
        val status = GameStatus.DRAW_AGREEMENT
        _uiState.update { it.copy(gameStatus = status) }
        audio.play(ChessSoundEffect.GAME_OVER)
        saveGameToHistory(status)
    }

    private fun saveGameToHistory(status: GameStatus) {
        val state = _uiState.value
        val pgnString = state.moveHistory.joinToString(" ") { it.sanNotation }
        val opponent = when (state.gameMode) {
            GameMode.VS_AI -> "AI (${state.aiDifficulty.vietnameseName})"
            GameMode.PASS_AND_PLAY -> "Người chơi 2"
            GameMode.PUZZLES -> "Thế cờ"
            GameMode.CHESS_CLOCK -> "Thi đấu"
        }

        viewModelScope.launch(Dispatchers.IO) {
            gameDao.insertGame(
                GameEntity(
                    mode = state.gameMode.vietnameseName,
                    difficulty = state.aiDifficulty.vietnameseName,
                    playerColor = state.playerColor.displayName(true),
                    opponentName = opponent,
                    result = status.message(true),
                    totalMoves = state.moveHistory.size,
                    movesPgn = pgnString,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            gameDao.clearAll()
        }
    }

    // --- Puzzles Management ---
    fun loadPuzzle(index: Int) {
        val puzzles = PuzzleRepository.puzzles
        if (index !in puzzles.indices) return

        val puzzle = puzzles[index]
        val puzzleBoard = ChessBoard.fromFen(puzzle.fen)

        _uiState.update {
            it.copy(
                currentPuzzleIndex = index,
                board = puzzleBoard,
                selectedSquare = null,
                legalMoves = emptyList(),
                moveHistory = emptyList(),
                lastMove = null,
                hintMove = null,
                puzzleStatus = PuzzleStatus.SOLVING,
                puzzleStepIndex = 0,
                showPuzzleHint = false,
                isFlipped = (puzzle.playerColor == PieceColor.BLACK)
            )
        }
    }

    fun togglePuzzleHint() {
        _uiState.update { it.copy(showPuzzleHint = !it.showPuzzleHint) }
    }

    fun nextPuzzle() {
        val nextIdx = (_uiState.value.currentPuzzleIndex + 1) % PuzzleRepository.puzzles.size
        loadPuzzle(nextIdx)
    }

    fun retryPuzzle() {
        loadPuzzle(_uiState.value.currentPuzzleIndex)
    }

    private fun handlePuzzleSquareClick(square: Square) {
        val state = _uiState.value
        val puzzle = PuzzleRepository.puzzles.getOrNull(state.currentPuzzleIndex) ?: return
        if (state.puzzleStatus == PuzzleStatus.SOLVED) return

        val board = state.board
        val currentPiece = board.getPiece(square)
        val selected = state.selectedSquare

        if (selected == null) {
            if (currentPiece != null && currentPiece.color == board.turn) {
                val legalMoves = ChessRules.getLegalMovesForSquare(board, square)
                _uiState.update { it.copy(selectedSquare = square, legalMoves = legalMoves) }
            }
        } else {
            val move = state.legalMoves.find { it.to == square }
            if (move != null) {
                val san = ChessRules.generateSan(board, move)
                val expectedSan = puzzle.expectedMovesSan.getOrNull(state.puzzleStepIndex)

                val isCleanSan = san.replace("+", "").replace("#", "")
                val isCleanExpected = expectedSan?.replace("+", "")?.replace("#", "")

                if (isCleanSan == isCleanExpected || san == expectedSan) {
                    // Correct move!
                    val nextBoard = ChessRules.applyMove(board, move.copy(sanNotation = san))
                    audio.play(if (move.capturedPiece != null) ChessSoundEffect.CAPTURE else ChessSoundEffect.MOVE)

                    val nextStep = state.puzzleStepIndex + 1
                    if (nextStep >= puzzle.expectedMovesSan.size) {
                        // Puzzle solved!
                        audio.play(ChessSoundEffect.GAME_OVER)
                        _uiState.update {
                            it.copy(
                                board = nextBoard,
                                selectedSquare = null,
                                legalMoves = emptyList(),
                                lastMove = move.copy(sanNotation = san),
                                puzzleStatus = PuzzleStatus.SOLVED,
                                puzzleStepIndex = nextStep
                            )
                        }
                    } else {
                        // Opponent automated response move
                        _uiState.update {
                            it.copy(
                                board = nextBoard,
                                selectedSquare = null,
                                legalMoves = emptyList(),
                                lastMove = move.copy(sanNotation = san),
                                puzzleStatus = PuzzleStatus.CORRECT_STEP,
                                puzzleStepIndex = nextStep
                            )
                        }

                        // Play opponent reply after brief delay
                        viewModelScope.launch {
                            delay(500)
                            val opponentSan = puzzle.expectedMovesSan.getOrNull(nextStep)
                            if (opponentSan != null) {
                                val opponentMoves = ChessRules.getLegalMoves(nextBoard, nextBoard.turn)
                                val oppMove = opponentMoves.find {
                                    val s = ChessRules.generateSan(nextBoard, it)
                                    s.replace("+", "").replace("#", "") == opponentSan.replace("+", "").replace("#", "")
                                } ?: opponentMoves.firstOrNull()

                                if (oppMove != null) {
                                    val afterOppBoard = ChessRules.applyMove(nextBoard, oppMove.copy(sanNotation = opponentSan))
                                    audio.play(if (oppMove.capturedPiece != null) ChessSoundEffect.CAPTURE else ChessSoundEffect.MOVE)
                                    _uiState.update {
                                        it.copy(
                                            board = afterOppBoard,
                                            lastMove = oppMove.copy(sanNotation = opponentSan),
                                            puzzleStepIndex = nextStep + 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Wrong move
                    audio.play(ChessSoundEffect.ILLEGAL)
                    _uiState.update {
                        it.copy(
                            puzzleStatus = PuzzleStatus.WRONG_MOVE,
                            selectedSquare = null,
                            legalMoves = emptyList()
                        )
                    }
                }
            } else if (currentPiece != null && currentPiece.color == board.turn) {
                val legalMoves = ChessRules.getLegalMovesForSquare(board, square)
                _uiState.update { it.copy(selectedSquare = square, legalMoves = legalMoves) }
            } else {
                _uiState.update { it.copy(selectedSquare = null, legalMoves = emptyList()) }
            }
        }
    }
}
