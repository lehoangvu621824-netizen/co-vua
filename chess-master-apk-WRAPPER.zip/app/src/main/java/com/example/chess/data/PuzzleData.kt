package com.example.chess.data

import com.example.chess.model.PieceColor

data class ChessPuzzle(
    val id: String,
    val title: String,
    val category: String,
    val difficulty: String,
    val fen: String,
    val playerColor: PieceColor,
    val expectedMovesSan: List<String>, // Alternating player move, opponent reply, player move...
    val hint: String,
    val explanation: String
)

object PuzzleRepository {
    val puzzles: List<ChessPuzzle> = listOf(
        ChessPuzzle(
            id = "p1",
            title = "Chiếu hết hàng đáy (Back-Rank Mate)",
            category = "Chiếu hết 1 nước",
            difficulty = "Dễ",
            fen = "6k1/5ppp/8/8/8/8/8/4R1K1 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Re8#"),
            hint = "Tận dụng hàng 8 không có lối thoát của vua đen!",
            explanation = "Xe trắng phi xuống e8 chiếu hết vì tốt đen chặn đường thoát của vua."
        ),
        ChessPuzzle(
            id = "p2",
            title = "Hậu bắt đôi và chiếu hết",
            category = "Chiếu hết 1 nước",
            difficulty = "Dễ",
            fen = "r1bqkb1r/pppp1ppp/2n5/4p3/2B1n3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Qxf7#"),
            hint = "Điểm yếu f7 thường thấy trong khai cuộc!",
            explanation = "Hậu trắng ăn tốt f7 dưới sự bảo kê của Tượng c4 tạo nên đòn Scholar's Mate kinh điển."
        ),
        ChessPuzzle(
            id = "p3",
            title = "Đòn Thắt Cổ (Smothered Mate)",
            category = "Chiếu hết 1 nước",
            difficulty = "Trung bình",
            fen = "6k1/5Npp/8/8/8/8/8/7K w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Nh6#"),
            hint = "Mã nhảy tới ô nào để chiếu vua khi vua bị chính quân mình vây hãm?",
            explanation = "Mã nhảy lên h6 chiếu kép hoặc chiếu chết khi quân đen tự chặn đường thoát của vua."
        ),
        ChessPuzzle(
            id = "p4",
            title = "Đòn bắt đôi Hoàng Gia của Mã",
            category = "Đòn chiến thuật",
            difficulty = "Dễ",
            fen = "r1bqk2r/pppp1ppp/8/4n3/2B5/2N5/PPP2PPP/R1BQK2R w KQkq - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Qe2", "Qe7", "f4"),
            hint = "Ghim Mã đen vào Vua trên cột e!",
            explanation = "Hậu e2 ghim Mã e5 vào vua đen, sau đó tốt f4 bắt sống Mã."
        ),
        ChessPuzzle(
            id = "p5",
            title = "Chiếu hết 2 nước với Xe và Tượng",
            category = "Chiếu hết 2 nước",
            difficulty = "Trung bình",
            fen = "5rk1/5p1p/6p1/8/8/1B6/8/4R1K1 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Re8", "Rxe8", "Bxf7#"),
            hint = "Dùng Xe đánh đổi để kéo quân phòng thủ hàng đáy!",
            explanation = "Trắng thí Xe đổi lấy sự kiểm soát tuyệt đối trên ô f7."
        ),
        ChessPuzzle(
            id = "p6",
            title = "Đòn Xiên (Skewer) Bắt Xe",
            category = "Đòn chiến thuật",
            difficulty = "Dễ",
            fen = "8/8/8/3k4/8/8/1B6/4R1K1 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Re5+", "Kd6", "Rxb5"),
            hint = "Dùng Xe chiếu buộc Vua chạy để bắt quân phía sau.",
            explanation = "Xe trắng chiếu vua đen buộc rời vị trí bảo vệ."
        ),
        ChessPuzzle(
            id = "p7",
            title = "Thí Hậu chiếu hết (Opera Game Mate)",
            category = "Chiếu hết 2 nước",
            difficulty = "Khó",
            fen = "4kb1r/p2n1ppp/4p3/3p4/8/4B3/P1Q2PPP/q4RK1 w k - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Qc8+", "Ke7", "Bc5#"),
            hint = "Đưa Hậu xuống hàng 8 dồn Vua đen vào góc chết!",
            explanation = "Hậu trắng chiếu ở c8 ép vua lên e7, sau đó Tượng c5 kết liễu trận đấu."
        ),
        ChessPuzzle(
            id = "p8",
            title = "Bẫy mở cột h chiếu hết",
            category = "Chiếu hết 2 nước",
            difficulty = "Trung bình",
            fen = "r1b2rk1/pp3ppp/2n5/3qp1N1/8/3B4/PPP2PPP/R2Q1RK1 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Bxh7+", "Kh8", "Qxd5"),
            hint = "Đòn mở chiếu (Discovered attack) bằng Tượng ăn tốt h7!",
            explanation = "Tượng ăn h7 chiếu vua đen đồng thời lộ mặt đường Hậu trắng bắt không Hậu d5 của đen."
        ),
        ChessPuzzle(
            id = "p9",
            title = "Chiếu hết Anastasias Mate",
            category = "Chiếu hết 2 nước",
            difficulty = "Khó",
            fen = "5rk1/1p3ppp/pN6/8/8/8/1PP2PPP/3R2K1 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Nd7", "Re8", "Nxf8"),
            hint = "Mã chiếm ô trọng yếu khống chế đường thoát!",
            explanation = "Mã chiếm d7 tấn công Xe f8 và kiểm soát ô quan trọng."
        ),
        ChessPuzzle(
            id = "p10",
            title = "Phong cấp Tốt quyết định",
            category = "Tàn cuộc",
            difficulty = "Dễ",
            fen = "8/4P3/8/8/8/4k3/8/4K3 w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("e8=Q+", "Kd3", "Qe4#"),
            hint = "Đẩy tốt lên hàng cuối và hóa Hậu!",
            explanation = "Tốt trắng phong Hậu chiếu vua đen ngay lập tức."
        ),
        ChessPuzzle(
            id = "p11",
            title = "Đòn Bắt Đôi Vua và Xe của Mã (Royal Fork)",
            category = "Đòn chiến thuật",
            difficulty = "Dễ",
            fen = "r3k3/8/8/3N4/8/8/8/4K3 w q - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Nc7+", "Kd7", "Nxa8"),
            hint = "Mã nhảy c7 chiếu vua đồng thời bắt xe a8!",
            explanation = "Nc7+ là đòn bắt đôi hoàn hảo giữa King và Rook."
        ),
        ChessPuzzle(
            id = "p12",
            title = "Chiếu hết Arab (Xe + Mã phối hợp)",
            category = "Chiếu hết 1 nước",
            difficulty = "Dễ",
            fen = "7k/5R2/5N2/8/8/8/8/7K w - - 0 1",
            playerColor = PieceColor.WHITE,
            expectedMovesSan = listOf("Rh7#"),
            hint = "Xe sang cột h dưới sự bảo vệ của Mã!",
            explanation = "Xe h7 chiếu hết, vua đen ở góc không thể thoát vì Mã f6 bịt mọi đường."
        )
    )
}
