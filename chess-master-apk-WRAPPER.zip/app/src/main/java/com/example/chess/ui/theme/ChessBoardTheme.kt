package com.example.chess.ui.theme

import androidx.compose.ui.graphics.Color

enum class BoardTheme(
    val displayName: String,
    val lightSquare: Color,
    val darkSquare: Color,
    val highlightSelected: Color,
    val highlightLegalMove: Color,
    val highlightLastMove: Color,
    val checkAlert: Color
) {
    WOOD(
        displayName = "Gỗ Cổ Điển",
        lightSquare = Color(0xFFF0D9B5),
        darkSquare = Color(0xFFB58863),
        highlightSelected = Color(0x99F6F669),
        highlightLegalMove = Color(0x6655B359),
        highlightLastMove = Color(0x88CDD26A),
        checkAlert = Color(0xBBE53935)
    ),
    TOURNAMENT_GREEN(
        displayName = "Xanh Thi Đấu",
        lightSquare = Color(0xFFEEEED2),
        darkSquare = Color(0xFF769656),
        highlightSelected = Color(0x99BACA44),
        highlightLegalMove = Color(0x6643A047),
        highlightLastMove = Color(0x88F7EC70),
        checkAlert = Color(0xBBE53935)
    ),
    OBSIDIAN_DARK(
        displayName = "Đá Hắc Diệu Thạch",
        lightSquare = Color(0xFFCFD8DC),
        darkSquare = Color(0xFF455A64),
        highlightSelected = Color(0x9980CBC4),
        highlightLegalMove = Color(0x6626A69A),
        highlightLastMove = Color(0x88FFD54F),
        checkAlert = Color(0xBBE53935)
    ),
    OCEAN_BLUE(
        displayName = "Biển Xanh",
        lightSquare = Color(0xFFE1F5FE),
        darkSquare = Color(0xFF0288D1),
        highlightSelected = Color(0x9980D8FF),
        highlightLegalMove = Color(0x6600E676),
        highlightLastMove = Color(0x88FFE082),
        checkAlert = Color(0xBBD32F2F)
    ),
    WARM_AMBER(
        displayName = "Hổ Phách",
        lightSquare = Color(0xFFFFF3E0),
        darkSquare = Color(0xFFBCAAA4),
        highlightSelected = Color(0x99FFE082),
        highlightLegalMove = Color(0x6681C784),
        highlightLastMove = Color(0x88FFB74D),
        checkAlert = Color(0xBBE53935)
    )
}
