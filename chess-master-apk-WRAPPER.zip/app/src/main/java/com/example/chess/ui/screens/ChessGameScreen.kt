package com.example.chess.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.chess.engine.ChessAI
import com.example.chess.model.*
import com.example.chess.ui.components.*
import com.example.chess.viewmodel.ChessUiState
import com.example.chess.viewmodel.ChessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChessGameScreen(
    viewModel: ChessViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var showMenu by remember { mutableStateOf(false) }
    var showDifficultyDialog by remember { mutableStateOf(false) }
    var showSideDialog by remember { mutableStateOf(false) }
    var showTimeControlDialog by remember { mutableStateOf(false) }
    var showGameOverDialog by remember { mutableStateOf(true) }

    // Re-enable game over dialog when game status changes to game over
    LaunchedEffect(uiState.gameStatus) {
        if (uiState.gameStatus.isGameOver) {
            showGameOverDialog = true
        }
    }

    val (materialAdv, capturedMap) = remember(uiState.board) {
        ChessAI.getMaterialAdvantage(uiState.board)
    }

    val whiteAdvantage = if (materialAdv > 0) materialAdv else 0
    val blackAdvantage = if (materialAdv < 0) -materialAdv else 0

    val topIsBlack = !uiState.isFlipped
    val topColor = if (topIsBlack) PieceColor.BLACK else PieceColor.WHITE
    val bottomColor = if (topIsBlack) PieceColor.WHITE else PieceColor.BLACK

    val topName = when (uiState.gameMode) {
        GameMode.VS_AI -> if (uiState.playerColor == topColor) "Bạn" else "AI Máy tính"
        GameMode.PASS_AND_PLAY -> if (topColor == PieceColor.WHITE) "Người chơi 1 (Trắng)" else "Người chơi 2 (Đen)"
        else -> topColor.displayName(true)
    }
    val bottomName = when (uiState.gameMode) {
        GameMode.VS_AI -> if (uiState.playerColor == bottomColor) "Bạn" else "AI Máy tính"
        GameMode.PASS_AND_PLAY -> if (bottomColor == PieceColor.WHITE) "Người chơi 1 (Trắng)" else "Người chơi 2 (Đen)"
        else -> bottomColor.displayName(true)
    }

    val isTopAI = uiState.gameMode == GameMode.VS_AI && uiState.playerColor != topColor
    val isBottomAI = uiState.gameMode == GameMode.VS_AI && uiState.playerColor != bottomColor

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (uiState.gameMode == GameMode.VS_AI) "Cờ Vua - Đấu với AI" else "Cờ Vua - 2 Người chơi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (uiState.gameMode == GameMode.VS_AI) {
                            Text(
                                text = "Độ khó: ${uiState.aiDifficulty.vietnameseName} (${uiState.aiDifficulty.rating})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleFlipBoard() },
                        modifier = Modifier.testTag("flip_board_button")
                    ) {
                        Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Xoay bàn cờ")
                    }

                    IconButton(
                        onClick = { viewModel.toggleSound() },
                        modifier = Modifier.testTag("sound_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Âm thanh"
                        )
                    }

                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("more_menu_button")
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Tùy chọn")
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Ván Mới") },
                            leadingIcon = { Icon(Icons.Default.Refresh, null) },
                            onClick = {
                                showMenu = false
                                viewModel.startNewGame()
                            }
                        )
                        if (uiState.gameMode == GameMode.VS_AI) {
                            DropdownMenuItem(
                                text = { Text("Chọn độ khó AI") },
                                leadingIcon = { Icon(Icons.Default.Psychology, null) },
                                onClick = {
                                    showMenu = false
                                    showDifficultyDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Chọn màu quân") },
                                leadingIcon = { Icon(Icons.Default.SwapHoriz, null) },
                                onClick = {
                                    showMenu = false
                                    showSideDialog = true
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Thời gian thi đấu") },
                            leadingIcon = { Icon(Icons.Default.Timer, null) },
                            onClick = {
                                showMenu = false
                                showTimeControlDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Xin thua ván đấu") },
                            leadingIcon = { Icon(Icons.Default.Flag, null) },
                            onClick = {
                                showMenu = false
                                viewModel.resignGame()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Xin hòa cờ") },
                            leadingIcon = { Icon(Icons.Default.Handshake, null) },
                            onClick = {
                                showMenu = false
                                viewModel.offerDraw()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Mode Switcher Pills
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                SegmentedButton(
                    selected = uiState.gameMode == GameMode.VS_AI,
                    onClick = { viewModel.setGameMode(GameMode.VS_AI) },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                ) {
                    Text("Đấu AI")
                }
                SegmentedButton(
                    selected = uiState.gameMode == GameMode.PASS_AND_PLAY,
                    onClick = { viewModel.setGameMode(GameMode.PASS_AND_PLAY) },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                ) {
                    Text("2 Người")
                }
            }

            // Top Player Header (Opponent)
            PlayerHeaderView(
                name = topName,
                rating = if (isTopAI) uiState.aiDifficulty.rating else null,
                isAI = isTopAI,
                color = topColor,
                isCurrentTurn = uiState.board.turn == topColor && !uiState.gameStatus.isGameOver,
                isThinking = isTopAI && uiState.isAiThinking,
                timeRemainingSeconds = if (topColor == PieceColor.WHITE) uiState.whiteTimeSeconds else uiState.blackTimeSeconds,
                capturedPieces = if (topColor == PieceColor.WHITE) capturedMap else emptyMap(),
                materialAdvantage = if (topColor == PieceColor.WHITE) whiteAdvantage else blackAdvantage,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Interactive Chess Board
            ChessBoardView(
                board = uiState.board,
                isFlipped = uiState.isFlipped,
                boardTheme = uiState.boardTheme,
                selectedSquare = uiState.selectedSquare,
                legalMoves = uiState.legalMoves,
                lastMove = uiState.lastMove,
                kingInCheckSquare = uiState.kingInCheckSquare,
                hintMove = uiState.hintMove,
                onSquareClicked = { viewModel.onSquareClicked(it) }
            )

            // Bottom Player Header (You / Local Player 1)
            PlayerHeaderView(
                name = bottomName,
                rating = if (isBottomAI) uiState.aiDifficulty.rating else null,
                isAI = isBottomAI,
                color = bottomColor,
                isCurrentTurn = uiState.board.turn == bottomColor && !uiState.gameStatus.isGameOver,
                isThinking = isBottomAI && uiState.isAiThinking,
                timeRemainingSeconds = if (bottomColor == PieceColor.WHITE) uiState.whiteTimeSeconds else uiState.blackTimeSeconds,
                capturedPieces = if (bottomColor == PieceColor.WHITE) capturedMap else emptyMap(),
                materialAdvantage = if (bottomColor == PieceColor.WHITE) whiteAdvantage else blackAdvantage,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Move History Ribbon
            MoveHistoryListView(
                moves = uiState.moveHistory,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Bottom Controls Row
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .padding(vertical = 6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalIconButton(
                        onClick = { viewModel.undoMove() },
                        modifier = Modifier.testTag("undo_button"),
                        enabled = uiState.moveHistory.isNotEmpty() && !uiState.isAiThinking
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = "Đi lại (Undo)")
                    }

                    FilledTonalIconButton(
                        onClick = { viewModel.requestHint() },
                        modifier = Modifier.testTag("hint_button"),
                        enabled = !uiState.gameStatus.isGameOver && !uiState.isAiThinking
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = "Gợi ý nước đi (Hint)")
                    }

                    FilledTonalIconButton(
                        onClick = { viewModel.toggleFlipBoard() },
                        modifier = Modifier.testTag("rotate_board_button")
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Đổi chiều bàn cờ")
                    }

                    Button(
                        onClick = { viewModel.startNewGame() },
                        modifier = Modifier.testTag("new_game_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ván Mới")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Promotion Dialog
        if (uiState.pendingPromotionFromTo != null) {
            PromotionDialog(
                color = uiState.board.turn,
                onSelect = { viewModel.onPromotionSelected(it) },
                onDismiss = { viewModel.dismissPromotion() }
            )
        }

        // Game Over Dialog
        if (uiState.gameStatus.isGameOver && showGameOverDialog) {
            GameOverDialog(
                status = uiState.gameStatus,
                winnerColor = when (uiState.gameStatus) {
                    GameStatus.CHECKMATE_WHITE_WINS, GameStatus.BLACK_RESIGNED, GameStatus.BLACK_TIMEOUT -> PieceColor.WHITE
                    GameStatus.CHECKMATE_BLACK_WINS, GameStatus.WHITE_RESIGNED, GameStatus.WHITE_TIMEOUT -> PieceColor.BLACK
                    else -> null
                },
                onNewGame = { viewModel.startNewGame() },
                onDismiss = { showGameOverDialog = false }
            )
        }

        // AI Difficulty Selection Dialog
        if (showDifficultyDialog) {
            AlertDialog(
                onDismissRequest = { showDifficultyDialog = false },
                title = { Text("Chọn Cấp Độ AI") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AIDifficulty.values().forEach { diff ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp)),
                                color = if (uiState.aiDifficulty == diff) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                onClick = {
                                    viewModel.setAIDifficulty(diff)
                                    showDifficultyDialog = false
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "${diff.vietnameseName} (${diff.displayName})",
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Trình độ: ${diff.rating}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (uiState.aiDifficulty == diff) {
                                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showDifficultyDialog = false }) {
                        Text("Đóng")
                    }
                }
            )
        }

        // Side Selection Dialog
        if (showSideDialog) {
            AlertDialog(
                onDismissRequest = { showSideDialog = false },
                title = { Text("Chọn Màu Quân Của Bạn") },
                text = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.setPlayerColor(PieceColor.WHITE)
                                showSideDialog = false
                            },
                            modifier = Modifier.weight(1f).padding(4.dp)
                        ) {
                            Text("Trắng (Đi trước)")
                        }
                        Button(
                            onClick = {
                                viewModel.setPlayerColor(PieceColor.BLACK)
                                showSideDialog = false
                            },
                            modifier = Modifier.weight(1f).padding(4.dp)
                        ) {
                            Text("Đen (Đi sau)")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSideDialog = false }) {
                        Text("Hủy")
                    }
                }
            )
        }

        // Time Control Dialog
        if (showTimeControlDialog) {
            AlertDialog(
                onDismissRequest = { showTimeControlDialog = false },
                title = { Text("Chọn Thời Gian Thi Đấu") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeControl.PRESETS.forEach { preset ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp)),
                                color = if (uiState.timeControl == preset) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                onClick = {
                                    viewModel.setTimeControl(preset)
                                    showTimeControlDialog = false
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(preset.label, fontWeight = FontWeight.Bold)
                                    if (uiState.timeControl == preset) {
                                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showTimeControlDialog = false }) {
                        Text("Đóng")
                    }
                }
            )
        }
    }
}
