package com.example.chess.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameEntity): Long

    @Query("SELECT * FROM game_history ORDER BY timestamp DESC")
    fun getAllGames(): Flow<List<GameEntity>>

    @Query("SELECT * FROM game_history WHERE id = :id LIMIT 1")
    suspend fun getGameById(id: Long): GameEntity?

    @Query("DELETE FROM game_history WHERE id = :id")
    suspend fun deleteGame(id: Long)

    @Query("DELETE FROM game_history")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM game_history")
    fun getGameCount(): Flow<Int>
}
