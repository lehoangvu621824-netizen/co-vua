package com.example.chess.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType

@Composable
fun ChessPieceView(
    piece: Piece,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.padding(2.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val isWhite = piece.color == PieceColor.WHITE
            val fillColor = if (isWhite) Color(0xFFFCFCFC) else Color(0xFF262626)
            val strokeColor = if (isWhite) Color(0xFF1E1E1E) else Color(0xFFECEFF1)
            val accentColor = if (isWhite) Color(0xFFE0E0E0) else Color(0xFF424242)

            when (piece.type) {
                PieceType.PAWN -> drawPawn(fillColor, strokeColor, accentColor)
                PieceType.KNIGHT -> drawKnight(fillColor, strokeColor, accentColor, isWhite)
                PieceType.BISHOP -> drawBishop(fillColor, strokeColor, accentColor)
                PieceType.ROOK -> drawRook(fillColor, strokeColor, accentColor)
                PieceType.QUEEN -> drawQueen(fillColor, strokeColor, accentColor)
                PieceType.KING -> drawKing(fillColor, strokeColor, accentColor)
            }
        }
    }
}

private fun DrawScope.drawPawn(fillColor: Color, strokeColor: Color, accentColor: Color) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.22f, h * 0.88f)
        lineTo(w * 0.78f, h * 0.88f)
        lineTo(w * 0.72f, h * 0.80f)
        lineTo(w * 0.28f, h * 0.80f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Body
    val bodyPath = Path().apply {
        moveTo(w * 0.30f, h * 0.80f)
        cubicTo(w * 0.35f, h * 0.65f, w * 0.40f, h * 0.50f, w * 0.42f, h * 0.44f)
        lineTo(w * 0.58f, h * 0.44f)
        cubicTo(w * 0.60f, h * 0.50f, w * 0.65f, h * 0.65f, w * 0.70f, h * 0.80f)
        close()
    }
    drawPath(bodyPath, fillColor, style = Fill)
    drawPath(bodyPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Collar
    drawRoundRect(
        color = fillColor,
        topLeft = Offset(w * 0.38f, h * 0.41f),
        size = Size(w * 0.24f, h * 0.06f),
        cornerRadius = CornerRadius(w * 0.03f, w * 0.03f),
        style = Fill
    )
    drawRoundRect(
        color = strokeColor,
        topLeft = Offset(w * 0.38f, h * 0.41f),
        size = Size(w * 0.24f, h * 0.06f),
        cornerRadius = CornerRadius(w * 0.03f, w * 0.03f),
        style = Stroke(strokeWidth)
    )

    // Head circle
    drawCircle(
        color = fillColor,
        radius = w * 0.16f,
        center = Offset(w * 0.50f, h * 0.28f),
        style = Fill
    )
    drawCircle(
        color = strokeColor,
        radius = w * 0.16f,
        center = Offset(w * 0.50f, h * 0.28f),
        style = Stroke(strokeWidth)
    )
    // Shine accent
    drawCircle(
        color = accentColor,
        radius = w * 0.04f,
        center = Offset(w * 0.45f, h * 0.24f),
        style = Fill
    )
}

private fun DrawScope.drawKnight(fillColor: Color, strokeColor: Color, accentColor: Color, isWhite: Boolean) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.20f, h * 0.88f)
        lineTo(w * 0.80f, h * 0.88f)
        lineTo(w * 0.74f, h * 0.80f)
        lineTo(w * 0.26f, h * 0.80f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Horse head and mane outline
    val knightPath = Path().apply {
        moveTo(w * 0.28f, h * 0.80f)
        // Chest curve
        cubicTo(w * 0.30f, h * 0.65f, w * 0.32f, h * 0.52f, w * 0.22f, h * 0.45f)
        // Muzzle
        lineTo(w * 0.24f, h * 0.38f)
        lineTo(w * 0.35f, h * 0.35f)
        // Nose bridge to ear
        lineTo(w * 0.48f, h * 0.18f)
        // Ear tip
        lineTo(w * 0.54f, h * 0.22f)
        // Mane back curve
        cubicTo(w * 0.65f, h * 0.28f, w * 0.76f, h * 0.45f, w * 0.72f, h * 0.80f)
        close()
    }
    drawPath(knightPath, fillColor, style = Fill)
    drawPath(knightPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Eye
    drawCircle(
        color = strokeColor,
        radius = w * 0.035f,
        center = Offset(w * 0.38f, h * 0.34f)
    )

    // Mane details
    val manePath = Path().apply {
        moveTo(w * 0.55f, h * 0.30f)
        lineTo(w * 0.66f, h * 0.42f)
        moveTo(w * 0.58f, h * 0.45f)
        lineTo(w * 0.68f, h * 0.58f)
    }
    drawPath(manePath, strokeColor, style = Stroke(strokeWidth * 0.9f, cap = StrokeCap.Round))
}

private fun DrawScope.drawBishop(fillColor: Color, strokeColor: Color, accentColor: Color) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.22f, h * 0.88f)
        lineTo(w * 0.78f, h * 0.88f)
        lineTo(w * 0.72f, h * 0.80f)
        lineTo(w * 0.28f, h * 0.80f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Mitre / Body
    val bodyPath = Path().apply {
        moveTo(w * 0.30f, h * 0.80f)
        cubicTo(w * 0.34f, h * 0.65f, w * 0.36f, h * 0.50f, w * 0.32f, h * 0.40f)
        cubicTo(w * 0.30f, h * 0.26f, w * 0.44f, h * 0.20f, w * 0.50f, h * 0.20f)
        cubicTo(w * 0.56f, h * 0.20f, w * 0.70f, h * 0.26f, w * 0.68f, h * 0.40f)
        cubicTo(w * 0.64f, h * 0.50f, w * 0.66f, h * 0.65f, w * 0.70f, h * 0.80f)
        close()
    }
    drawPath(bodyPath, fillColor, style = Fill)
    drawPath(bodyPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Bishop Slit
    drawLine(
        color = strokeColor,
        start = Offset(w * 0.42f, h * 0.32f),
        end = Offset(w * 0.58f, h * 0.44f),
        strokeWidth = strokeWidth * 1.2f,
        cap = StrokeCap.Round
    )

    // Top small cross/ball
    drawCircle(
        color = fillColor,
        radius = w * 0.055f,
        center = Offset(w * 0.50f, h * 0.15f),
        style = Fill
    )
    drawCircle(
        color = strokeColor,
        radius = w * 0.055f,
        center = Offset(w * 0.50f, h * 0.15f),
        style = Stroke(strokeWidth)
    )
}

private fun DrawScope.drawRook(fillColor: Color, strokeColor: Color, accentColor: Color) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.20f, h * 0.88f)
        lineTo(w * 0.80f, h * 0.88f)
        lineTo(w * 0.74f, h * 0.78f)
        lineTo(w * 0.26f, h * 0.78f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Tower Body
    val towerPath = Path().apply {
        moveTo(w * 0.30f, h * 0.78f)
        lineTo(w * 0.33f, h * 0.42f)
        lineTo(w * 0.67f, h * 0.42f)
        lineTo(w * 0.70f, h * 0.78f)
        close()
    }
    drawPath(towerPath, fillColor, style = Fill)
    drawPath(towerPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Battlements / Castles
    val battlementsPath = Path().apply {
        moveTo(w * 0.24f, h * 0.42f)
        lineTo(w * 0.24f, h * 0.25f)
        lineTo(w * 0.36f, h * 0.25f)
        lineTo(w * 0.36f, h * 0.32f)
        lineTo(w * 0.44f, h * 0.32f)
        lineTo(w * 0.44f, h * 0.25f)
        lineTo(w * 0.56f, h * 0.25f)
        lineTo(w * 0.56f, h * 0.32f)
        lineTo(w * 0.64f, h * 0.32f)
        lineTo(w * 0.64f, h * 0.25f)
        lineTo(w * 0.76f, h * 0.25f)
        lineTo(w * 0.76f, h * 0.42f)
        close()
    }
    drawPath(battlementsPath, fillColor, style = Fill)
    drawPath(battlementsPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))
}

private fun DrawScope.drawQueen(fillColor: Color, strokeColor: Color, accentColor: Color) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.20f, h * 0.88f)
        lineTo(w * 0.80f, h * 0.88f)
        lineTo(w * 0.74f, h * 0.78f)
        lineTo(w * 0.26f, h * 0.78f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Crown points
    val crownPath = Path().apply {
        moveTo(w * 0.28f, h * 0.78f)
        cubicTo(w * 0.32f, h * 0.60f, w * 0.22f, h * 0.38f, w * 0.18f, h * 0.32f)
        lineTo(w * 0.33f, h * 0.46f)
        lineTo(w * 0.42f, h * 0.26f)
        lineTo(w * 0.50f, h * 0.44f)
        lineTo(w * 0.58f, h * 0.26f)
        lineTo(w * 0.67f, h * 0.46f)
        lineTo(w * 0.82f, h * 0.32f)
        cubicTo(w * 0.78f, h * 0.38f, w * 0.68f, h * 0.60f, w * 0.72f, h * 0.78f)
        close()
    }
    drawPath(crownPath, fillColor, style = Fill)
    drawPath(crownPath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Crown jewels (circles on tips)
    val tipPoints = arrayOf(
        Offset(w * 0.18f, h * 0.30f),
        Offset(w * 0.42f, h * 0.24f),
        Offset(w * 0.58f, h * 0.24f),
        Offset(w * 0.82f, h * 0.30f)
    )
    for (pt in tipPoints) {
        drawCircle(color = fillColor, radius = w * 0.035f, center = pt, style = Fill)
        drawCircle(color = strokeColor, radius = w * 0.035f, center = pt, style = Stroke(strokeWidth * 0.8f))
    }
}

private fun DrawScope.drawKing(fillColor: Color, strokeColor: Color, accentColor: Color) {
    val w = size.width
    val h = size.height
    val strokeWidth = w * 0.04f

    // Base
    val basePath = Path().apply {
        moveTo(w * 0.20f, h * 0.88f)
        lineTo(w * 0.80f, h * 0.88f)
        lineTo(w * 0.74f, h * 0.78f)
        lineTo(w * 0.26f, h * 0.78f)
        close()
    }
    drawPath(basePath, fillColor, style = Fill)
    drawPath(basePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Crown Mantle
    val mantlePath = Path().apply {
        moveTo(w * 0.28f, h * 0.78f)
        cubicTo(w * 0.32f, h * 0.60f, w * 0.26f, h * 0.46f, w * 0.26f, h * 0.34f)
        cubicTo(w * 0.36f, h * 0.42f, w * 0.64f, h * 0.42f, w * 0.74f, h * 0.34f)
        cubicTo(w * 0.74f, h * 0.46f, w * 0.68f, h * 0.60f, w * 0.72f, h * 0.78f)
        close()
    }
    drawPath(mantlePath, fillColor, style = Fill)
    drawPath(mantlePath, strokeColor, style = Stroke(strokeWidth, join = StrokeJoin.Round))

    // Central cross
    val crossH = h * 0.08f
    val crossW = w * 0.12f
    // Vertical bar
    drawLine(
        color = strokeColor,
        start = Offset(w * 0.50f, h * 0.14f),
        end = Offset(w * 0.50f, h * 0.34f),
        strokeWidth = strokeWidth * 1.5f,
        cap = StrokeCap.Square
    )
    // Horizontal bar
    drawLine(
        color = strokeColor,
        start = Offset(w * 0.50f - crossW / 2, h * 0.21f),
        end = Offset(w * 0.50f + crossW / 2, h * 0.21f),
        strokeWidth = strokeWidth * 1.5f,
        cap = StrokeCap.Square
    )
}
