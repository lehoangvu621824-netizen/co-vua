package com.example.chess.model

enum class PieceColor {
    WHITE, BLACK;

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE
    fun displayName(isVietnamese: Boolean = true): String = when (this) {
        WHITE -> if (isVietnamese) "Trắng" else "White"
        BLACK -> if (isVietnamese) "Đen" else "Black"
    }
}

enum class PieceType(val symbol: Char, val baseValue: Int, val vietnameseName: String) {
    PAWN('P', 100, "Tốt"),
    KNIGHT('N', 320, "Mã"),
    BISHOP('B', 330, "Tượng"),
    ROOK('R', 500, "Xe"),
    QUEEN('Q', 900, "Hậu"),
    KING('K', 20000, "Vua");

    val sanLetter: String
        get() = when (this) {
            PAWN -> ""
            KNIGHT -> "N"
            BISHOP -> "B"
            ROOK -> "R"
            QUEEN -> "Q"
            KING -> "K"
        }
}

data class Piece(
    val type: PieceType,
    val color: PieceColor
) {
    val fenChar: Char = if (color == PieceColor.WHITE) type.symbol else type.symbol.lowercaseChar()
}

data class Square(val col: Int, val row: Int) {
    init {
        require(col in 0..7 && row in 0..7) { "Square coordinate out of bounds: col=$col, row=$row" }
    }

    val algebraic: String
        get() = "${('a' + col)}${row + 1}"

    val isLight: Boolean
        get() = (col + row) % 2 != 0

    companion object {
        fun fromAlgebraic(alg: String): Square {
            require(alg.length >= 2)
            val c = alg[0].lowercaseChar() - 'a'
            val r = alg[1].digitToInt() - 1
            return Square(c, r)
        }
    }
}

data class Move(
    val from: Square,
    val to: Square,
    val piece: Piece,
    val capturedPiece: Piece? = null,
    val promotion: PieceType? = null,
    val isCastling: Boolean = false,
    val isKingsideCastle: Boolean = false,
    val isQueensideCastle: Boolean = false,
    val isEnPassant: Boolean = false,
    val sanNotation: String = ""
)

enum class GameStatus {
    NOT_STARTED,
    IN_PROGRESS,
    CHECKMATE_WHITE_WINS,
    CHECKMATE_BLACK_WINS,
    STALEMATE,
    DRAW_INSUFFICIENT_MATERIAL,
    DRAW_FIFTY_MOVES,
    DRAW_THREEFOLD_REPETITION,
    DRAW_AGREEMENT,
    WHITE_RESIGNED,
    BLACK_RESIGNED,
    WHITE_TIMEOUT,
    BLACK_TIMEOUT;

    val isGameOver: Boolean
        get() = this != NOT_STARTED && this != IN_PROGRESS

    fun message(isVietnamese: Boolean = true): String = when (this) {
        NOT_STARTED -> if (isVietnamese) "Chưa bắt đầu" else "Not started"
        IN_PROGRESS -> if (isVietnamese) "Đang diễn ra" else "In progress"
        CHECKMATE_WHITE_WINS -> if (isVietnamese) "Chiếu hết! Trắng thắng" else "Checkmate! White wins"
        CHECKMATE_BLACK_WINS -> if (isVietnamese) "Chiếu hết! Đen thắng" else "Checkmate! Black wins"
        STALEMATE -> if (isVietnamese) "Hòa cờ (Hết nước đi / Stalemate)" else "Draw by stalemate"
        DRAW_INSUFFICIENT_MATERIAL -> if (isVietnamese) "Hòa cờ (Không đủ lực lượng chiếu hết)" else "Draw by insufficient material"
        DRAW_FIFTY_MOVES -> if (isVietnamese) "Hòa cờ (Luật 50 nước không ăn quân/đi tốt)" else "Draw by 50-move rule"
        DRAW_THREEFOLD_REPETITION -> if (isVietnamese) "Hòa cờ (Lặp lại 3 lần thế cờ)" else "Draw by threefold repetition"
        DRAW_AGREEMENT -> if (isVietnamese) "Hòa cờ (Hai bên thỏa thuận)" else "Draw by agreement"
        WHITE_RESIGNED -> if (isVietnamese) "Trắng xin thua! Đen thắng" else "White resigned! Black wins"
        BLACK_RESIGNED -> if (isVietnamese) "Đen xin thua! Trắng thắng" else "Black resigned! White wins"
        WHITE_TIMEOUT -> if (isVietnamese) "Trắng hết giờ! Đen thắng" else "White timed out! Black wins"
        BLACK_TIMEOUT -> if (isVietnamese) "Đen hết giờ! Trắng thắng" else "Black timed out! White wins"
    }
}

enum class AIDifficulty(val displayName: String, val vietnameseName: String, val rating: String, val searchDepth: Int) {
    EASY("Easy", "Dễ", "~800 Elo", 1),
    MEDIUM("Medium", "Trung bình", "~1300 Elo", 2),
    HARD("Hard", "Khó", "~1700 Elo", 3),
    MASTER("Master", "Chuyên gia", "~2100 Elo", 4)
}

enum class GameMode(val vietnameseName: String, val englishName: String) {
    VS_AI("Đấu với AI", "Play vs AI"),
    PASS_AND_PLAY("2 Người chơi", "Pass & Play"),
    PUZZLES("Câu đố thế cờ", "Chess Puzzles"),
    CHESS_CLOCK("Đồng hồ thi đấu", "Chess Clock")
}

data class CastlingRights(
    val whiteKingSide: Boolean = true,
    val whiteQueenSide: Boolean = true,
    val blackKingSide: Boolean = true,
    val blackQueenSide: Boolean = true
) {
    fun toFenString(): String {
        val sb = StringBuilder()
        if (whiteKingSide) sb.append('K')
        if (whiteQueenSide) sb.append('Q')
        if (blackKingSide) sb.append('k')
        if (blackQueenSide) sb.append('q')
        return if (sb.isEmpty()) "-" else sb.toString()
    }

    companion object {
        fun fromFen(fen: String): CastlingRights {
            return CastlingRights(
                whiteKingSide = fen.contains('K'),
                whiteQueenSide = fen.contains('Q'),
                blackKingSide = fen.contains('k'),
                blackQueenSide = fen.contains('q')
            )
        }
    }
}

data class TimeControl(
    val initialSeconds: Int,
    val incrementSeconds: Int,
    val label: String
) {
    companion object {
        val BULLET_1_0 = TimeControl(60, 0, "1 min")
        val BLITZ_3_2 = TimeControl(180, 2, "3 | 2")
        val BLITZ_5_3 = TimeControl(300, 3, "5 | 3")
        val RAPID_10_0 = TimeControl(600, 0, "10 min")
        val CLASSICAL_15_10 = TimeControl(900, 10, "15 | 10")
        val UNLIMITED = TimeControl(0, 0, "Không giới hạn")

        val PRESETS = listOf(UNLIMITED, BLITZ_3_2, BLITZ_5_3, RAPID_10_0, CLASSICAL_15_10, BULLET_1_0)
    }
}
