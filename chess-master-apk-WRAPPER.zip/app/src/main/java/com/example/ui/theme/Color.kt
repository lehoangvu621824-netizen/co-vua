package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ChessGoldPrimary = Color(0xFFC7923E)
val ChessGoldLight = Color(0xFFE5B567)
val ChessWoodDark = Color(0xFF2C241E)
val ChessWoodMedium = Color(0xFF534338)
val ChessBoardGreen = Color(0xFF4E7837)
val ChessBoardLightGreen = Color(0xFF769656)

val DarkPrimary = Color(0xFFE5B567)
val DarkOnPrimary = Color(0xFF3F2E00)
val DarkPrimaryContainer = Color(0xFF5B4300)
val DarkOnPrimaryContainer = Color(0xFFFFDF9E)
val DarkSecondary = Color(0xFF9EBA7A)
val DarkBackground = Color(0xFF191715)
val DarkSurface = Color(0xFF221F1C)
val DarkSurfaceVariant = Color(0xFF332D28)

val LightPrimary = Color(0xFF8A5D00)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFFFDF9E)
val LightOnPrimaryContainer = Color(0xFF2B1B00)
val LightSecondary = Color(0xFF4E7837)
val LightBackground = Color(0xFFFCF8F4)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEFE9E2)

