package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.chess.model.GameMode
import com.example.chess.ui.screens.ChessClockScreen
import com.example.chess.ui.screens.ChessGameScreen
import com.example.chess.ui.screens.HistoryScreen
import com.example.chess.ui.screens.PuzzlesScreen
import com.example.chess.ui.screens.SettingsScreen
import com.example.chess.viewmodel.ChessViewModel
import com.example.ui.theme.MyApplicationTheme

enum class MainNavigationTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    PLAY("Chơi Cờ", Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports),
    PUZZLES("Câu Đố", Icons.Filled.Psychology, Icons.Outlined.Psychology),
    CLOCK("Đồng Hồ", Icons.Filled.Timer, Icons.Outlined.Timer),
    HISTORY("Lịch Sử", Icons.Filled.History, Icons.Outlined.History),
    SETTINGS("Cài Đặt", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val chessViewModel: ChessViewModel = viewModel()
                var currentTab by remember { mutableStateOf(MainNavigationTab.PLAY) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar {
                            MainNavigationTab.values().forEach { tab ->
                                val isSelected = currentTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        currentTab = tab
                                        when (tab) {
                                            MainNavigationTab.PLAY -> chessViewModel.setGameMode(GameMode.VS_AI)
                                            MainNavigationTab.PUZZLES -> chessViewModel.setGameMode(GameMode.PUZZLES)
                                            MainNavigationTab.CLOCK -> chessViewModel.setGameMode(GameMode.CHESS_CLOCK)
                                            else -> {}
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    when (currentTab) {
                        MainNavigationTab.PLAY -> ChessGameScreen(
                            viewModel = chessViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavigationTab.PUZZLES -> PuzzlesScreen(
                            viewModel = chessViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavigationTab.CLOCK -> ChessClockScreen(
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavigationTab.HISTORY -> HistoryScreen(
                            viewModel = chessViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavigationTab.SETTINGS -> SettingsScreen(
                            viewModel = chessViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
