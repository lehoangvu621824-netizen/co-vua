# Cờ Vua — APK 32-bit ARM

Project Android WebView đóng gói từ `co-vua-6-1.html`.

## Build bằng GitHub Actions
1. Tạo repository GitHub.
2. Upload toàn bộ thư mục project này.
3. Vào **Actions** → **Build APK** → **Run workflow**.
4. Khi chạy xong, mở phần **Artifacts** và tải `co-vua-arm32-apk`.
5. Giải nén artifact để lấy APK.

APK được cấu hình ABI `armeabi-v7a` (ARM 32-bit).
