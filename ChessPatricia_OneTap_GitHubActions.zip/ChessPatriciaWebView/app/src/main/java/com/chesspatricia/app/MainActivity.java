package com.chesspatricia.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.ConnectivityManager;
import android.net.Network;
import android.content.Context;
import android.widget.Toast;

import java.io.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private WebView webView;
    private PatriciaBridge bridge;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        bridge = new PatriciaBridge(this);
        webView.addJavascriptInterface(bridge, "PatriciaEngine");
        webView.addJavascriptInterface(bridge, "AndroidPatricia");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy() {
        if (bridge != null) bridge.stop();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    public static class PatriciaBridge {
        private final Context ctx;
        private Process process;
        private BufferedWriter stdin;
        private BufferedReader stdout;
        private boolean ready = false;

        PatriciaBridge(Context c) { ctx = c.getApplicationContext(); }

        @JavascriptInterface
        public synchronized String getBestMove(String fen) { return runUci(fen); }

        @JavascriptInterface
        public synchronized String downloadAndGetBestMove(String fen, String ignoredUrl) { return runUci(fen); }

        @JavascriptInterface
        public synchronized String loadFromUrlAndGetBestMove(String fen, String ignoredUrl) { return runUci(fen); }

        private boolean hasInternet() {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            return n != null && cm.getNetworkCapabilities(n) != null;
        }

        private String findNativeEngine() throws Exception {
            String abi = android.os.Build.SUPPORTED_ABIS[0];
            if (!abi.equals("arm64-v8a") && !abi.equals("x86_64")) throw new Exception("Unsupported ABI: " + abi);
            // Android packages jniLibs as native library directories, but Patricia is an executable.
            // Locate the packaged APK entry and extract it.
            String apk = ctx.getApplicationInfo().sourceDir;
            java.util.zip.ZipFile z = new java.util.zip.ZipFile(apk);
            String entryName = "lib/" + abi + "/libPatricia.so";
            java.util.zip.ZipEntry e = z.getEntry(entryName);
            if (e == null) {
                entryName = "lib/" + abi + "/Patricia";
                e = z.getEntry(entryName);
            }
            if (e == null) { z.close(); throw new Exception("Patricia binary not packaged for " + abi); }
            File out = new File(ctx.getFilesDir(), "Patricia");
            if (!out.exists() || out.length() != e.getSize()) {
                InputStream in = z.getInputStream(e); FileOutputStream fos = new FileOutputStream(out);
                byte[] buf = new byte[8192]; int n; while ((n=in.read(buf))!=-1) fos.write(buf,0,n);
                fos.close(); in.close(); out.setExecutable(true, false);
            }
            z.close();
            return out.getAbsolutePath();
        }

        private void start() throws Exception {
            if (ready && process != null && process.isAlive()) return;
            String path = findNativeEngine();
            process = new ProcessBuilder(path).redirectErrorStream(true).start();
            stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
            stdout = new BufferedReader(new InputStreamReader(process.getInputStream()));
            send("uci"); waitFor("uciok", 4000);
            send("isready"); waitFor("readyok", 4000);
            ready = true;
        }

        private void send(String s) throws Exception { stdin.write(s); stdin.write("\n"); stdin.flush(); }

        private String waitFor(String token, long ms) throws Exception {
            long end = System.currentTimeMillis()+ms; String line;
            while (System.currentTimeMillis()<end && (line=stdout.readLine())!=null) {
                if (line.contains(token)) return line;
            }
            throw new IOException("UCI timeout: "+token);
        }

        private String runUci(String fen) {
            if (!hasInternet()) return ""; // Patricia is intentionally network-required in this app.
            try {
                start();
                send("position fen " + fen);
                send("go movetime 1200");
                long end=System.currentTimeMillis()+5000; String line;
                while (System.currentTimeMillis()<end && (line=stdout.readLine())!=null) {
                    if (line.startsWith("bestmove ")) {
                        String[] p=line.trim().split("\\s+");
                        return p.length>1 ? p[1] : "";
                    }
                }
            } catch(Exception e) { ready=false; stop(); }
            return "";
        }

        synchronized void stop() {
            try { if(stdin!=null){stdin.write("quit\n"); stdin.flush();} } catch(Exception ignored){}
            try { if(process!=null) process.destroy(); } catch(Exception ignored){}
            process=null; stdin=null; stdout=null; ready=false;
        }
    }
}
