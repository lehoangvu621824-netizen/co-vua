ChessPatriciaWebView

Android WebView app with a JavaScript bridge that runs the bundled Patricia 5.1 UCI engine.
The HTML file is loaded from app/src/main/assets/index.html.
Bridge names exposed to JavaScript:
  window.PatriciaEngine.getBestMove(fen)
  window.PatriciaEngine.loadFromUrlAndGetBestMove(fen, url)
  window.AndroidPatricia.getBestMove(fen)
  window.AndroidPatricia.downloadAndGetBestMove(fen, url)

Patricia is intentionally network-required: the bridge returns no move when there is no active network.
The Patricia 5.1 executable is bundled for arm64-v8a and x86_64.
Stockfish 18 and Reckless are left in the supplied HTML unchanged.

Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).
