BUILD APK ON PHONE

1. Create a GitHub repository and upload this whole folder's contents.
2. Open the repository -> Actions -> Build APK -> Run workflow.
3. Wait for the green check.
4. Open the workflow run -> Artifacts -> ChessPatriciaWebView-APK -> download ZIP.
5. Extract the APK and install it on Android.

The workflow uses GitHub-hosted runners to build the APK, so no computer or Android Studio is required on your phone.
