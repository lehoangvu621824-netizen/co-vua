package com.example.chessnative;
import android.content.*; import android.graphics.*; import android.view.*;
public class NativeChessBoard extends View {
 Paint p=new Paint(1); String[][] b={{"♜","♞","♝","♛","♚","♝","♞","♜"},{"♟","♟","♟","♟","♟","♟","♟","♟"},{"","","","","","","",""},{"","","","","","","",""},{"","","","","","","",""},{"","","","","","","",""},{"♙","♙","♙","♙","♙","♙","♙","♙"},{"♖","♘","♗","♕","♔","♗","♘","♖"}};
 public NativeChessBoard(Context c){super(c);}
 protected void onDraw(Canvas c){float z=Math.min(getWidth(),getHeight()),x=(getWidth()-z)/2,y=(getHeight()-z)/2,q=z/8;
  for(int r=0;r<8;r++)for(int f=0;f<8;f++){p.setColor((r+f)%2==0?Color.rgb(240,217,181):Color.rgb(181,136,99));c.drawRect(x+f*q,y+r*q,x+(f+1)*q,y+(r+1)*q,p);if(!b[r][f].isEmpty()){p.setColor(Color.BLACK);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(q*.72f);c.drawText(b[r][f],x+f*q+q/2,y+r*q+q*.72f,p);}}
 }
}