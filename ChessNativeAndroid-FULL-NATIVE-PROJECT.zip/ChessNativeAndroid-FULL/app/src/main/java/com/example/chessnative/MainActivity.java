package com.example.chessnative;
import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(1024,1024);
  LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setBackgroundColor(Color.BLACK);
  NativeChessBoard board=new NativeChessBoard(this); r.addView(board,new LinearLayout.LayoutParams(0,-1,1f));
  LinearLayout s=new LinearLayout(this); s.setOrientation(LinearLayout.VERTICAL); s.setPadding(12,0,0,0);
  TextView t=new TextView(this); t.setText("CỜ VUA\nNative Android\n\nNhật ký nước đi"); t.setTextColor(Color.WHITE); t.setTextSize(18); s.addView(t);
  ScrollView v=new ScrollView(this); TextView j=new TextView(this); j.setText("1. —    —\n2. —    —\n3. —    —"); j.setTextColor(Color.WHITE); j.setTextSize(16); v.addView(j); s.addView(v,new LinearLayout.LayoutParams(-1,0,1f));
  LinearLayout n=new LinearLayout(this); Button u=new Button(this);u.setText("←");u.setOnClickListener(x->board.invalidate());
  Button q=new Button(this);q.setText("→");q.setOnClickListener(x->board.invalidate());n.addView(u,new LinearLayout.LayoutParams(0,-2,1f));n.addView(q,new LinearLayout.LayoutParams(0,-2,1f));s.addView(n);
  r.addView(s,new LinearLayout.LayoutParams(360,-1)); setContentView(r);
 }
}