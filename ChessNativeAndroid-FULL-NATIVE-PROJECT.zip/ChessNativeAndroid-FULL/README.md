# ChessNativeAndroid
Native Android project based on the supplied chess HTML.

Original HTML is preserved unchanged at `source_reference/original-chess.html` (6226 lines detected).
The runtime screen is native Android `Activity` + custom `View`; it does NOT load the HTML in WebView.

This is a native project foundation. Full conversion of every JavaScript feature (rules, journal, clocks, eval bar, Stockfish integration, etc.) requires porting those modules into native Java/Kotlin; Build APK alone cannot convert JavaScript into native code.
